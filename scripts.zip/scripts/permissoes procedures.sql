
/*
- Cria uma tabela temporaria para inserir o resultado da consulta das permiss�es das procedures;
- Para analisar a permiss�o dos usu�rios, etc;

#procedure #permission #permissao #grant #usuario #login
*/
CREATE TABLE #tmp (
	[owner] varchar(50), 
	[object] varchar(50), 
	[grantee] varchar(50), 
	[grantor] varchar(50), 
	[protecttype] varchar(50), 
	[action] varchar(50), 
	[column] varchar(50)
)

drop table #tmp

select 'INSERT INTO  #tmp EXEC sp_helprotect ''' + name + ''''
from sysobjects
where xtype = 'P'
order by name

INSERT INTO  #tmp EXEC sp_helprotect 'rpt_MillsComparisonExcel'

SELECT * FROM #tmp


