/*
http://www.mssqltips.com/tip.asp?tip=1112
http://sqlblogcasts.com/blogs/tonyrogerson/archive/2006/07/11/881.aspx
http://www.mcdbabrasil.com.br/modules.php?name=News&file=article&sid=545
*/
CREATE DATABASE TesteFG
GO

USE TesteFG
GO

--Cria File Group
ALTER DATABASE TesteFG
ADD FILEGROUP FG_Indices
GO

ALTER DATABASE TesteFG
ADD FILEGROUP FG_LargeTable
GO

--Adicionando arquivo associado ao FileGroup
ALTER DATABASE TesteFG
ADD FILE ( 
	NAME = FG_Indices,
	FILENAME = 'C:\Program Files\Microsoft SQL Server\MSSQL10.MSSQLSERVER\MSSQL\DATA\TesteFG_FG_Indices.ndf',
	SIZE = 5MB,
	MAXSIZE = 100MB,
	FILEGROWTH = 5MB
	) TO FILEGROUP FG_Indices;
GO

ALTER DATABASE TesteFG
ADD FILE ( 
	NAME = FG_LargeTable,
	FILENAME = 'C:\Program Files\Microsoft SQL Server\MSSQL10.MSSQLSERVER\MSSQL\DATA\TesteFG_FG_LargeTable.ndf',
	SIZE = 5MB,
	MAXSIZE = 100MB,
	FILEGROWTH = 5MB
	) TO FILEGROUP FG_LargeTable;
GO

--Cria tabela associada ao FileGroup
CREATE TABLE dbo.Tabela1 (
	OrderID int NOT NULL,
	ProductID int NOT NULL,
	CustomerID int NOT NULL, 
	UnitPrice money NOT NULL,
	OrderQty smallint NOT NULL
) ON FG_LargeTable 

-- Cria Indice associado ao FileGroup
CREATE INDEX IDX_OrderID ON dbo.Tabela1(OrderID)
ON FG_Indices
GO 

/* Movendo objectos entre FileGroups
Quando criamos um CLUSTERED INDEX em um FileGroup espec�fico
a tabela relacionada tamb�m � movida para este FileGroup
*/
CREATE CLUSTERED INDEX IDX_ProductID ON dbo.Tabela1(ProductID) 
ON FG_LargeTable
GO 
  
/* Movendo NONCLUSTERED INDEX
Neste caso estamos criando um novo indice no FileGroup desejado
e DROPANDO o INDICE existente */
CREATE INDEX IDX_OrderID ON dbo.Tabela1(OrderID) 
WITH (DROP_EXISTING = ON)
ON FG_LargeTable
GO 

select i.*, o.*
from sysindexes i, sysobjects o
where i.id = o.id
and i.name not like '_WA%'
and o.xtype = 'U'

sp_help tabela1
 
select *
from sysdepends 

EXEC sys.sp_helpindex 'IDX_OrderID'

sp_helpindex 'dbo.Tabela1'

select * from sysindexkeys

select * from sysindexes

select * from syscolumns

select * from sysobjects

Column name Data type Description 
id int ID of the table 
indid smallint ID of the index 
colid smallint ID of the column 
keyno smallint Position of the column in the index 


select o.id, o.name, i.name, c.name, *
from sysindexkeys ik, sysobjects o, sysindexes i, syscolumns c
where ik.id = o.id
and ik.indid = i.indid
and i.id = o.id
and ik.colid = c.colid
and o.id = c.id
and o.xtype = 'U'
