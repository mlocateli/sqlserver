

/*
A fun��o databasepropertyex � muito util caso voc� precise verificar as propriedades
de uma database. Neste caso, criei um script para alterar o Recovery Model de todas
as databases que estavam utilizando Recovey Model SIMPLE.
*/

-- retorna a propriedade especifica de uma database
select databasepropertyex('master', 'Recovery')

-- seleciona as databases com recovery model SIMPLE e
-- cria um script para alterar o recovery model de SIMPLE para FULL
select 'ALTER DATABASE ' + name + ' SET RECOVERY FULL'
from master.dbo.sysdatabases 
where databasepropertyex(name, 'Recovery') = 'SIMPLE' 
and name not in ('master', 'model', 'tempdb', 'msdb')
order by name

