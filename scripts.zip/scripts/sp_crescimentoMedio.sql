USE [DBA]
GO

/****** Object:  StoredProcedure [dbo].[retorna_crescimento_medio]    Script Date: 13/08/2015 15:39:35 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

create procedure [dbo].[retorna_crescimento_medio] (@database varchar (100), @num_dias int, @output int output)
as
begin

--cria tabela que ira receber as coletas
declare @table table
(
	[database]			varchar(100),
	[data_coleta]		datetime,
	[espaco_consumido]	int
)

--popula tabela com os valores coletados
insert into @table
select [database_name], [date], [used]
from [dba].[dbo].[databasesize] a 
	inner join [master].[sys].[databases] b on b.name COLLATE DATABASE_DEFAULT = a.database_name COLLATE DATABASE_DEFAULT and b.state = 0
where type = 0 and database_name = @database and date > getdate() - @num_dias
order by [date] asc;

--cria tabela q
with tbldifference as
(
	select row_number() over (order by data_coleta) as rownumber, data_coleta, espaco_consumido from @table
)

--descobre media de crescimento (desconsidera negativo)
select 
	@output = avg((cur.espaco_consumido-prv.espaco_consumido)*8)/1024
from tbldifference cur left outer join tbldifference prv
	on cur.rownumber=prv.rownumber+1
where
	(cur.espaco_consumido-prv.espaco_consumido) >= 0
end

GO


