DECLARE @version nvarchar(128);
SET @version = CAST(serverproperty('ProductVersion') AS nvarchar);
SET @version = CAST(SUBSTRING(@version, 1, CHARINDEX('.', @version) - 1) as int);

IF (@version >= 11) 
	BEGIN
		select 
			bs.database_name as [database],
			CASE
				WHEN bs.type = 'D' THEN 'Full'
				WHEN bs.type = 'I' THEN 'Differential'
				WHEN bs.type = 'L' THEN 'Log'
			END as [backup_type],
			substring(CONVERT(varchar(max), MAX(backup_start_date), 21),0,20) as [start_date],
			substring(CONVERT(varchar(max), MAX(bs.backup_finish_date), 21),0,20) as [finish_date],
			CAST((CAST(DATEDIFF(hh, MAX(bs.backup_start_date), MAX(bs.backup_finish_date)) AS int)) AS varchar) + ' hrs, ' + 
			CAST((CAST(DATEDIFF(mi, MAX(bs.backup_start_date), MAX(bs.backup_finish_date)) AS int))%60 AS varchar) + ' mins, ' + 
			CAST((CAST(DATEDIFF(ss, MAX(bs.backup_start_date), MAX(bs.backup_finish_date)) AS int))%60 AS varchar) + ' secs' 
			AS [duration],
			CAST(MAX(bs.backup_size)/1024/1024 as decimal(16,2)) as [size_mb]
		FROM 
			msdb.dbo.backupset bs
		WHERE
			bs.backup_start_date > DATEADD(DD, -90,GETDATE()) 
			AND bs.type IN ('D','I','L') 
			AND	bs.database_name IN (select name from master.sys.databases where state = 0) 
			--AND master.dbo.fn_database_is_read_write(bs.database_name) = 1
		GROUP BY 
			bs.database_name, 
			bs.type
	END
ELSE 
	BEGIN
		select 
			bs.database_name as [database],
			CASE
				WHEN bs.type = 'D' THEN 'Full'
				WHEN bs.type = 'I' THEN 'Differential'
				WHEN bs.type = 'L' THEN 'Log'
			END as [backup_type],
			substring(CONVERT(varchar(max), MAX(backup_start_date), 21),0,20) as [start_date],
			substring(CONVERT(varchar(max), MAX(bs.backup_finish_date), 21),0,20) as [finish_date],
			CAST((CAST(DATEDIFF(hh, MAX(bs.backup_start_date), MAX(bs.backup_finish_date)) AS int)) AS varchar) + ' hrs, ' + 
			CAST((CAST(DATEDIFF(mi, MAX(bs.backup_start_date), MAX(bs.backup_finish_date))%60 AS int)) AS varchar) + ' mins, ' + 
			CAST((CAST(DATEDIFF(ss, MAX(bs.backup_start_date), MAX(bs.backup_finish_date))%60 AS int)) AS varchar) + ' secs' 
			AS [duration],
			CAST(MAX(bs.backup_size)/1024/1024 as decimal(16,2)) as [size_mb]
		FROM 
			msdb.dbo.backupset bs
		WHERE
			bs.backup_start_date > DATEADD(DD, -90,GETDATE()) AND
			bs.type IN ('D','I','L') AND
			bs.database_name IN (select name from master.sys.databases where state = 0)
		GROUP BY 
			bs.database_name, 
			bs.type
	END
GO