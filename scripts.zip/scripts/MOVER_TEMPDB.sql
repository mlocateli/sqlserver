/*
###########################################################################################
#							SCRIPT PARA MOVER A BASE TEMPDB                        #
# Este script deve ser executado passo-a-passo, pois o trabalho ser� executado por etapas #
# Primeiro deve-se descobrir o nome l�gico, depois alterar nos caminhos e executar.     	#
# Feitos os procedimentos de recupera��o do nome l�gico e execu��o, pode-se converir tudo #
###########################################################################################
*/

--1) IDENTIFICAR OS NOMES L�GICOS DOS ARQUIVOS DO TEMPDB

SELECT name, physical_name AS CurrentLocation
FROM sys.master_files
WHERE database_id = DB_ID(N'tempdb');
GO

--2) ALTERAR O LOCAL DE CADA ARQUIVO
USE master;
GO
ALTER DATABASE tempdb 
MODIFY FILE (NAME = tempdev, FILENAME = 'E:\MSSQL\Data\tempdb.mdf');
GO
ALTER DATABASE tempdb 
MODIFY FILE (NAME = templog, FILENAME = 'E:\MSSQL\Data\templog.ldf');
GO

--3) PARE O SERVI�O DO SQL SERVER E INICIE NOVAMENTE

--4) RENOMEIE OU DELETE OS ARQUIVOS ANTIGOS DO TEMPDB 

--5) CONFIRA SE TUDO OCORREU COM SUCESSO
SELECT name, physical_name AS CurrentLocation, state_desc
FROM sys.master_files
WHERE database_id = DB_ID(N'tempdb');