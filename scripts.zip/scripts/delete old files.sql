

--Cannot use the ForFiles command as in the local delete, as it does not work on UNC locations
DECLARE @FilePath VARCHAR(150)
DECLARE @CmdString VARCHAR(200)
DECLARE @FileMask VARCHAR(10)
DECLARE @FileName VARCHAR(50)
DECLARE @FileDate VARCHAR(20)

SET @FilePath = 'C:\Temp\'
SET @FileMask = '.txt'

CREATE TABLE #tmpFiles
	(FileName varchar(150) )

--Now, delete any old files from the network path that are older than 7 days
--First, get the output of the dir command and put into a table to parse
SET @CmdString = 'dir ' + @FilePath + '*' + @FileMask

INSERT INTO #tmpFiles
EXEC master.dbo.xp_cmdshell @CmdString

--Delete rows that are not file listing or are null
DELETE
FROM #tmpFiles
WHERE Filename NOT LIKE '%' + @FileMask
OR Filename IS NULL

--Set up the cursor to loop through the records and delete each one, filtering by file date
--Reverse the record to get the filename, to get the first space from the left of the reversed name
--Delete backup files older than 7 days
--Para os arquivos que contem espa�o no nome, precisei identificar e ajustar em separado
DECLARE FileCursor CURSOR
FOR SELECT 	'Hourly' + REVERSE( SUBSTRING( REVERSE(Filename), 0, CHARINDEX('ylruoH', REVERSE(Filename) ) ) ), 
		SUBSTRING(Filename, 1, 22)
 FROM #tmpFiles
WHERE DATEDIFF( dd, CONVERT(DATETIME, LEFT( Filename, 20) ), GETDATE() ) > 5

OPEN FileCursor

FETCH NEXT FROM FileCursor
INTO @FileName, @FileDate

WHILE @@FETCH_STATUS = 0
BEGIN
	SET @CmdString = 'del "' + @FilePath + @FileName + '"'

	--EXEC master.dbo.xp_cmdshell @CmdString
	PRINT (@CmdString)
	
	FETCH NEXT FROM FileCursor
	INTO @FileName, @FileDate
END

CLOSE FileCursor
DEALLOCATE FileCursor

DROP TABLE #tmpFiles

