
/*
Verifica as TRIGGERS existentes na INST�NCIA
*/

select *
from sys.server_triggers

/*
CRIA / ALTERA as TRIGGERS existentes
*/

USE [master]
GO

CREATE TRIGGER [RestrictAccessPerHostName] ON ALL SERVER
FOR LOGON
AS
BEGIN
	IF (ORIGINAL_LOGIN() = 'app_col_odi_mkt' 
		AND HOST_NAME() NOT IN('CFS-007120','app1pfcodi1p','CF012194L', 'app1odi2h.hom.sicredi.net'))
	BEGIN		
		ROLLBACK;
	END
END
GO

ENABLE TRIGGER [RestrictAccessPerHostName] ON ALL SERVER
GO

