set nocount on

declare @date char(12)
declare @month char(3)
declare @day char(3)
declare @path varchar(500)
declare @total int
declare @line int
declare @database_name varchar(200)
declare @cmd varchar(800)

declare @date_old char(12)
declare @month_old char(3)
declare @day_old char(3)

set @path	= 'D:\backup\'

set @month 	= '0' + convert(char(2), datepart(mm, getdate()))
set @day 	= '0' + convert(char(2), datepart(dd, getdate()))

set @date = convert(char(4), datepart(yyyy, getdate())) + rtrim(right(@month, 2)) + rtrim(right(@day, 2)) 
		  + convert(char(2), datepart(HOUR, GETDATE()))

--select @date

select identity(int, 1, 1) as ordem, name 
into #databases 
from master..sysdatabases (nolock) 
where name = 'aSa_app'
order by name

select @line = 1, @total = Max(ordem) from #databases

while (@line <= @total)
begin
	select @database_name = name from #databases where ordem = @line
	set @cmd = 'backup log ' + @database_name + ' to disk = ' + '''' + rtrim(ltrim(@path)) + rtrim(ltrim(@date)) + '_LOG_BK_DB_' + rtrim(ltrim(@database_name)) + '.trn' + '''' + ' with init'
	exec(@cmd)
	print @cmd
	set @line = @line + 1
end


---- loop to delete old database backups
set @line = 1

-- set the date for removal as 2 days
set @month_old 	= '0' + convert(char(2), datepart(mm,  dateadd(d, -2, getdate())))
set @day_old 	= '0' + convert(char(2), datepart(dd,  dateadd(d, -2, getdate())))
set @date_old   = convert(char(4), datepart(yyyy,  dateadd(d, -2, getdate()))) + rtrim(right(@month_old, 2)) + rtrim(right(@day_old, 2))
				+ convert(char(2), datepart(HOUR, GETDATE()))



while (@line <= @total)
begin
	select @database_name = name from #databases where ordem = @line
	set @cmd = 'del "'  + rtrim(ltrim(@path)) + rtrim(ltrim(@date_old)) + '_LOG_BK_DB_' + rtrim(ltrim(@database_name)) + '.trn"'
	EXEC master.dbo.xp_cmdshell @cmd
	print @cmd
	set @line = @line + 1
end


--select * from #databases
drop table #databases

set nocount on

go


