--http://www.sqlservercentral.com/Forums/Topic291798-148-1.aspx
--http://www.devmedia.com.br/post-6090-Como-exportar-dados-do-SQL-Server-para-arquivo-XML-usando-BCP.html

DROP VIEW Teste

CREATE VIEW Teste
AS 
SELECT Cod_Atendimento, Tipo_Atendimento, Tipo_Visita, Nome_Cliente, Nome_Produto, Nome_Tecnico, 
	Inicio_Atendimento, Fim_Atendimento, Ano_Cadastro, Mes_Cadastro
FROM dbo.fatoVIsitas
GO
 
select top 1 *
from Teste
for XML AUTO, elements

DECLARE @CMD VARCHAR(100)

SET @CMD = 'select top 30 * from teste'

EXEC XP_CMDSHELL 'BCP ''select top 30 * from teste'' QUERYOUT c:\teste.txt -S. -U sa -P P@ssw0rd -c'

EXEC XP_CMDSHELL 'BCP "select top 1 * from InterOpDW.dbo.Teste 
FOR XML RAW(''PRODUTO''), ELEMENTS, ROOT(''PRODUTOS'')" QUERYOUT C:\result.xml -T -c'

bcp "SELECT top 1 * from interopdw.dbo.teste for xml auto, elements" queryout result.xml -T -c

exec xp_cmdshell 'bcp "select * from interopdw.dbo.ferias for xml auto, elements, root(''row'')" queryout c:\ferias.xml -T -c'

select top 3 *
from Teste 
FOR XML RAW('PRODUTO'), ELEMENTS, ROOT('PRODUTOS')

select top 10 *
from Teste 
FOR XML auto, ELEMENTS, ROOT('Chamados')

--comando ok
exec xp_cmdshell 'bcp "select * from interopdw.dbo.teste where nome_tecnico = ''Marcos Gontarski'' for xml auto, elements, root(''Chamado'')" queryout c:\result.xml -S. -T -c -w -r'

--"ISO-8859-1"

