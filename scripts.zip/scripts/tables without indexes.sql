/*
Query para listar tabelas sem index clustered (HEAP). 
Traz tamb�m o numero de registros e espa�o alocado 
pelos dados e indices (non clustered), se existirem.
*/

DECLARE @table_name VARCHAR(500)
DECLARE @schema_name VARCHAR(500)

create TABLE #tab1 (
        tablename VARCHAR (500)
       ,nr_indexes VARCHAR(500)
)

CREATE TABLE #temp_Table (
        tablename sysname
       ,row_count INT
       ,reserved VARCHAR(50)
       ,data VARCHAR(50)
       ,index_size VARCHAR(50)
       ,unused VARCHAR(50) 
)

INSERT INTO #tab1
SELECT DISTINCT [TABLE] = OBJECT_NAME(OBJECT_ID), COUNT (index_id)-1 nr_indexes
FROM SYS.INDEXES s
WHERE  s.type <> 1 and
            --INDEX_ID = 0 AND
            OBJECTPROPERTY(OBJECT_ID,'IsUserTable') = 1
            and not exists (select * from SYS.INDEXES s1 where s.object_id=s1.object_id and s1.type=1)
group by OBJECT_ID
ORDER BY [TABLE]

DECLARE c1 CURSOR FOR
	SELECT Table_Schema + '.' + Table_Name 
	FROM information_schema.tables t1
	WHERE TABLE_TYPE = 'BASE TABLE'

OPEN c1
FETCH NEXT FROM c1 INTO @table_name

WHILE @@FETCH_STATUS = 0
BEGIN 
        SET @table_name = REPLACE(@table_name, '[','');
        SET @table_name = REPLACE(@table_name, ']','');

        -- make sure the object exists before calling sp_spacedused
        IF EXISTS(SELECT id FROM sysobjects WHERE id = OBJECT_ID(@table_name))
        BEGIN
               INSERT INTO #temp_Table EXEC sp_spaceused @table_name, false;
        END

        FETCH NEXT FROM c1 INTO @table_name

END

CLOSE c1
DEALLOCATE c1

SELECT  t1.*
       ,t2.*
FROM #temp_Table t1
INNER JOIN #tab1 t2 ON (t1.tablename = t2.tablename )
WHERE t1.row_count > 0
ORDER BY row_count desc, data desc, nr_indexes,t1.tablename;

DROP TABLE #temp_Table

DROP TABLE #tab1


