
use evolutionpro
go

update spb_tb_leg_protocolos
set dt_hr_entrada = getdate(),
dt_hr_envio = null,
flg_enviar = 'S',
flg_proc_util = 'N',
dt_hr_lock = '1900-01-01',
guid_lock = '00000000-0000-0000-0000-000000000000'
where guid_operacao in (select guid_operacao
from spb_tb_pil_operacoes (nolock)
where dt_movto = '2020-03-16'
and left(cd_msg, 3) in ('PAG', 'STR')
and cd_msg like '%R2')

