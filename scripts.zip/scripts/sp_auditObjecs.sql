CREATE PROCEDURE sp_auditObjects (@db varchar(200) = NULL)
AS

/*** Verifica o collation para evitar erros no join entre database_permissions e sysusers ***/
DECLARE @Collation as SYSNAME
SET @Collation = cast(DATABASEPROPERTYEX('Tempdb', 'Collation') as nvarchar)

/*** Seleciona os usuários e as permissões deles nos objetos do banco ***/
DECLARE @sql nvarchar(max)
SET @sql = 'use '+ISNULL(@db, db_name(db_id()))+' 

SELECT 
	CASE sp.is_disabled    
	WHEN 0 THEN ''Enabled''
	ELSE ''Disabled''   
	END AS status,
	su.name as db_user, 
	so.name as db_object,  
	dp.state_desc as permission_type,
	dp.permission_name as permission
FROM sys.database_permissions dp
	join sys.sysusers su on (dp.grantee_principal_id = su.uid)
	join sys.sysobjects so on (dp.major_id = so.id)
	join sys.server_principals sp on (su.name COLLATE '+ @Collation +' = sp.name)
WHERE sp.name not in (''dbo'', ''public'') 
	and sp.type not in (''A'', ''R'', ''C'', ''K'')
ORDER BY su.name '

EXEC(@sql)

/*** Fim ***/
GO