
RESTORE verifyonly 
FROM DISK = 'c:\temp\WSS_Content_backup_201004192300.bak'

RESTORE DATABASE ProjectServer_Reporting
FROM DISK = 'c:\temp\ProjectServer_Reporting_backup_201004182300.bak'
WITH REPLACE,
	MOVE 'ProjectServer_Reporting'     TO 'C:\Program Files\Microsoft SQL Server\MSSQL.1\MSSQL\Data\ProjectServer_Reporting.mdf',
	MOVE 'ProjectServer_Reporting_log' TO 'C:\Program Files\Microsoft SQL Server\MSSQL.1\MSSQL\Data\ProjectServer_Reporting_Log.mdf',
	MOVE 'Logs_REponting'          TO 'C:\Program Files\Microsoft SQL Server\MSSQL.1\MSSQL\Data\Logs_Reporting_Log.mdf';

