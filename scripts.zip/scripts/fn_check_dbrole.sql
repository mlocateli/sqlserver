CREATE OR ALTER FUNCTION [dbo].[fn_check_dbrole] (@db_name sysname)  
RETURNS BIT  
AS  
BEGIN  
DECLARE  
 @ver nvarchar(64),  
 @db_state TINYINT,  
 @role TINYINT  
  
 SET @ver = CAST(serverproperty('ProductVersion') AS nvarchar)  
 SET @ver = SUBSTRING(@ver, 1, CHARINDEX('.', @ver) - 1)  
  
 /* SQL SERVER >= 2012 */  
 IF (@ver > '10')  
 BEGIN  
  SELECT   
   @db_state = db.state, @role = hars.role  
  FROM   
   sys.databases db  
   LEFT JOIN sys.dm_hadr_availability_replica_states hars ON db.replica_id = hars.replica_id  
  WHERE   
   db.name = @db_name  

  /* @db_state = 0 -> ONLINE */   
  /* @role = 1     -> PRIMARY */  
  /* @role IS NULL -> NOT IN AVG */  
  
  IF @db_state = 0 AND (@role = 1 OR @role IS NULL)  
  BEGIN  
   RETURN 1  
  END  
  
  /* OTHERS */  
  ELSE  
  BEGIN  
   RETURN 0  
  END  
  
  RETURN 0  
  
 END  
  
 /* SQL SERVER < 2012 */  
 ELSE  
 BEGIN  
  SELECT   
   @db_state = db.state, @role = m.mirroring_role  
  FROM   
   sys.databases db  
   LEFT JOIN sys.database_mirroring m on m.database_id = db.database_id  
  WHERE  
   db.name = @db_name  
  
  /* @db_state = 0 -> ONLINE */   
  /* @role = 1     -> PRIMARY */  
  /* @role IS NULL -> NOT IN MIRROR */  
  
  IF @db_state = 0 AND (@role = 1 OR @role IS NULL)  
  BEGIN  
   RETURN 1  
  END  
  
  /* OTHERS */  
  ELSE  
  BEGIN  
   RETURN 0  
  END  
 END  
  
 RETURN 0  
END  
