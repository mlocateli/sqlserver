
-- sql server change data capture

USE [Newcon4_tst4f]  
GO  

EXEC sys.sp_cdc_enable_db  
GO 

USE [Newcon4_tst4f]  
GO  

-- enable cdc for a table
EXEC sys.sp_cdc_enable_table  
@source_schema = N'dbo',  
@source_name   = N'bens',  
@role_name     = N'null',  
--@filegroup_name = N'MyDB_CT',  
@supports_net_changes = 1  
GO  

select convert(varchar(19), max(tran_end_time),120) as data_hora_scn from [Newcon4_tst4f].[cdc].[lsn_time_mapping]

EXEC sys.sp_cdc_disable_db  
GO 

EXEC sys.sp_cdc_start_job @job_type = 'capture'

EXEC sys.sp_cdc_stop_job @job_type = 'capture'

EXEC sp_cdc_change_job @job_type='capture', @maxtrans = 500, @maxscans = 10, @continuous = 1, @pollinginterval = 5


EXEC sys.sp_cdc_start_job @job_type = 'cleanup'

EXEC sys.sp_cdc_stop_job @job_type = 'cleanup'

EXEC sp_cdc_change_job @job_type='cleanup', @retention = 4320, @threshold = 5000

