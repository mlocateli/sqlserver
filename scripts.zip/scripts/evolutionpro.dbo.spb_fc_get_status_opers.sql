
CREATE FUNCTION dbo.spb_fc_get_status_opers (
                                             @pInstFinanc      int,
                                             @pFilialInst      int,
                                             @pDtMovtoDe       varchar(10),
                                             @pDtMovtoAte      varchar(10),
                                             @pCodMsg          varchar(max),
                                             @pGrupoMsg        varchar(3),
                                             @pCleardest       varchar(8),
                                             @pDBCR            varchar(10),
                                             @pTipoMsg         varchar(10),
                                             @pIdLegado        int,
                                             @pHrIni           int,
                                             @pHrFim           int,
                                             @pVlIni           numeric(20, 2),
                                             @pVlFim           numeric(20, 2),
                                             @pHrEnvioIni      int,
                                             @pHrEnvioFim      int,
                                             @pHrRetornoIni    int,
                                             @pHrRetornoFim    int,
                                             @DomSPB           varchar(10),
                                             @pSelicPaga       varchar(1),
                                             @fl_interno       int,
                                             @id_usr_filtrando int
                                            )
RETURNS @tab_retorno TABLE 
       (
       id_linha     int IDENTITY,
       str_linha    varchar(2000)
       PRIMARY KEY(id_linha)
       )      
AS
BEGIN
 
       DECLARE @st_operacao int, 
             @ds_status    varchar(500),
             @str_linha    varchar(2000)
 
       DECLARE @tab_status TABLE
             (
             st_operacao int
             )
 
       DECLARE @tab_st_finaliza TABLE
             (
             st_operacao int
             PRIMARY KEY(st_operacao)
             )
 
       DECLARE @tab_msgs_acesso TABLE
             (
             cd_msg varchar(10) COLLATE DATABASE_DEFAULT
             PRIMARY KEY(cd_msg)
             )
             
       SET @pDtMovtoDe  = SUBSTRING(@pDtMovtoDe, 7, 4) + SUBSTRING(@pDtMovtoDe, 4, 2) + SUBSTRING(@pDtMovtoDe, 1, 2)
       SET @pDtMovtoAte = SUBSTRING(@pDtMovtoAte, 7, 4) + SUBSTRING(@pDtMovtoAte, 4, 2) + SUBSTRING(@pDtMovtoAte, 1, 2)
 
       -- Inicio - Devido a mudan�a da tabela do Piloto armazenar o hor�rio no formato HHMMSS,
       -- devemos preencher com os zeros necess�rios os hor�rios informados
       IF NOT @pHrIni IS NULL BEGIN
          SET @pHrIni = CAST(RIGHT('0000' + CAST(@pHrIni AS varchar(10)), 4) + '00' AS int)
       END
 
       IF NOT @pHrFim IS NULL BEGIN
          SET @pHrFim = CAST(RIGHT('0000' + CAST(@pHrFim AS varchar(10)), 4) + '59' AS int)
       END
 
       IF NOT @pHrEnvioIni IS NULL BEGIN
          SET @pHrEnvioIni = CAST(RIGHT('0000' + CAST(@pHrEnvioIni AS varchar(10)), 4) + '00' AS int)
       END
 
       IF NOT @pHrEnvioFim IS NULL BEGIN
          SET @pHrEnvioFim = CAST(RIGHT('0000' + CAST(@pHrEnvioFim AS varchar(10)), 4) + '59' AS int)
       END
 
       IF NOT @pHrRetornoIni IS NULL BEGIN
          SET @pHrRetornoIni = CAST(RIGHT('0000' + CAST(@pHrRetornoIni AS varchar(10)), 4) + '00' AS int)
       END
 
       IF NOT @pHrRetornoFim IS NULL BEGIN
          SET @pHrRetornoFim = CAST(RIGHT('0000' + CAST(@pHrRetornoFim AS varchar(10)), 4) + '59' AS int)
       END
       -- T�rmino - Devido a mudan�a da tabela do Piloto armazenar o hor�rio no formato HHMMSS,
       -- devemos preencher com os zeros necess�rios os hor�rios informados
 
       -- Inicio - Cria lista de Mensagens a serem listadas
       DECLARE @tab_cd_msg TABLE (cd_msg varchar(10)COLLATE DATABASE_DEFAULT PRIMARY KEY(cd_msg))
 
       IF LTRIM(RTRIM(@pCodMsg)) <> '' BEGIN
          INSERT INTO @tab_cd_msg
          SELECT coluna 
            FROM dbo.spb_fc_preenche_tab_from_str_com_separador(@pCodMsg)
       END
       -- T�rmino - Cria lista de Mensagens a serem listadas
 
       INSERT INTO @tab_msgs_acesso
       SELECT DISTINCT
           a.cd_msg
         FROM spb_tb_cad_mens_func_grupo a WITH (NOLOCK)
         JOIN spb_tb_cad_usuarios_grupo  b WITH (NOLOCK) ON b.id_grupo_usuario = a.id_grupo_usuario
       WHERE a.id_funcionalidade = 353 -- ID da funcionalidade para Listar Opera��es no Mon de Oper
          AND b.id_usuario        = @id_usr_filtrando
 
       IF NOT @pCodMsg IS NULL BEGIN
          DELETE 
            FROM @tab_msgs_acesso
           WHERE NOT cd_msg IN (SELECT cd_msg FROM @tab_cd_msg)
       END
 
       -- Inicio - Cria lista de Mensagens a serem listadas
       DECLARE @tab_tp_legados TABLE (fl_interno bit PRIMARY KEY(fl_interno))
 
       IF NOT @fl_interno IS NULL BEGIN
          INSERT INTO @tab_tp_legados VALUES (@fl_interno)
       END
       ELSE BEGIN
          INSERT INTO @tab_tp_legados VALUES (0)
          INSERT INTO @tab_tp_legados VALUES (1)
       END
       -- T�rmino - Cria lista de Mensagens a serem listadas
 
       -- Inicio - Povoa a tabela com o Status Finalizadores
       INSERT INTO @tab_st_finaliza
       SELECT st_operacao
         FROM spb_tb_gen_status_oper WITH (NOLOCK)
       WHERE flg_repres_status IN ('C', 'R')
 
       -- Seleciona registros j� Finalizados sem chamar a Function "spb_fc_get_ult_st_oper" que possui processamento pesado
       INSERT INTO @tab_status
       SELECT DISTINCT
              a.st_operacao
         FROM spb_tb_pil_operacoes                a WITH (NOLOCK) 
         JOIN @tab_msgs_acesso                    b                ON b.cd_msg      = a.cd_msg LEFT OUTER
         JOIN spb_tb_cad_legados                  c WITH (NOLOCK)  ON c.id_legado   = a.id_legado
                                                                  AND c.fl_interno IN (SELECT fl_interno FROM @tab_tp_legados)
         JOIN spb_tb_cad_inst_financ_cosolidadora d WITH (NOLOCK) ON d.id_inst_financ  = a.id_inst_financ
                                                                 AND d.id_inst_selec   = @pInstFinanc
                                                                 AND d.id_filial_inst  = a.id_filial_inst
                                                                 AND d.id_filial_selec = @pFilialInst
       WHERE ((a.dt_movto       BETWEEN @pDtMovtoDe AND @pDtMovtoAte
          AND   a.dt_agendt      IS NULL)
           OR  (a.dt_movto       BETWEEN @pDtMovtoDe AND @pDtMovtoAte
          AND   a.dt_agendt      IS NOT NULL)
           OR  (a.dt_movto       BETWEEN LEFT(@pDtMovtoDe, 6) + '01' AND @pDtMovtoAte
          AND   a.dt_agendt      BETWEEN @pDtMovtoDe AND @pDtMovtoAte))
          AND  a.st_operacao     IN (SELECT st_operacao FROM @tab_st_finaliza)
          AND (@pCleardest       IS NULL OR a.clearing_dest    = @pCleardest) 
          AND (@pIdLegado        IS NULL OR a.id_legado        = @pIdLegado) 
          AND (@pHrIni           IS NULL OR a.hr_prog         >= @pHrIni) 
          AND (@pHrFim           IS NULL OR a.hr_prog         <= @pHrFim) 
          AND (@pHrEnvioIni      IS NULL OR a.hr_envio        >= @pHrEnvioIni) 
          AND (@pHrEnvioFim      IS NULL OR a.hr_envio        <= @pHrEnvioFim) 
          AND (@pHrRetornoIni    IS NULL OR a.hr_confirmacao  >= @pHrRetornoIni) 
          AND (@pHrRetornoFim    IS NULL OR a.hr_confirmacao  <= @pHrRetornoFim) 
          AND (@pTipoMsg         IS NULL OR a.tp_oper_grid     = @pTipoMsg)
          AND (@DomSPB           IS NULL OR dbo.spb_fc_get_node_value(a.str_xml, 'DomSist') = @DomSPB)
          AND (@pSelicPaga       IS NULL OR @pSelicPaga        = CASE WHEN LEFT(a.cd_msg, 3) = 'SEL' THEN dbo.spb_fc_filtro_oper_paga(a.guid_operacao, a.cd_msg, a.nr_ctrl_if, a.st_operacao, a.dt_movto, DATEADD(d, 5, a.dt_movto))
                                                                      ELSE '0'
                                                                 END)
          AND (@pGrupoMsg        IS NULL OR LEFT(a.cd_msg, 3)  = @pGrupoMsg) 
          AND (@pVlIni           IS NULL OR dbo.spb_fc_vrf_vl_oper_ini(@pDBCR, a.vl_operacao, @pVlIni) = 1) 
          AND (@pVlFim           IS NULL OR dbo.spb_fc_vrf_vl_oper_fim(@pDBCR, a.vl_operacao, @pVlFim) = 1) 
 
       -- Seleciona registros N�O Finalizados chamando a Function "spb_fc_get_ult_st_oper" com menor quantidade de registros
       INSERT INTO @tab_status
       SELECT DISTINCT
           dbo.spb_fc_get_ult_st_oper(a.guid_operacao, a.st_operacao)
         FROM spb_tb_pil_operacoes                a WITH (NOLOCK)
         JOIN spb_tb_cad_inst_financ_cosolidadora b WITH (NOLOCK)  ON b.id_inst_financ   = a.id_inst_financ 
                                                                  AND b.id_filial_inst   = a.id_filial_inst
                                                                  AND b.id_inst_selec    = @pInstFinanc
                                                                  AND b.id_filial_selec  = @pFilialInst LEFT
         JOIN spb_tb_cad_legados                  c WITH (NOLOCK)  ON c.id_legado   = a.id_legado
                                                                  AND c.fl_interno IN (SELECT fl_interno FROM @tab_tp_legados)
         JOIN @tab_msgs_acesso                    d                ON d.cd_msg      = a.cd_msg
       WHERE ((a.dt_movto       BETWEEN @pDtMovtoDe AND @pDtMovtoAte
          AND   a.dt_agendt      IS NULL)
           OR  (a.dt_movto       BETWEEN @pDtMovtoDe AND @pDtMovtoAte
          AND   a.dt_agendt      IS NOT NULL)
           OR  (a.dt_movto       BETWEEN LEFT(@pDtMovtoDe, 6) + '01' AND @pDtMovtoAte
          AND   a.dt_agendt      BETWEEN @pDtMovtoDe AND @pDtMovtoAte))
          AND  NOT a.st_operacao IN (SELECT st_operacao FROM @tab_st_finaliza)
          AND (@pCleardest       IS NULL OR a.clearing_dest    = @pCleardest) 
          AND (@pIdLegado        IS NULL OR a.id_legado        = @pIdLegado) 
          AND (@pHrIni           IS NULL OR a.hr_prog         >= @pHrIni) 
          AND (@pHrFim           IS NULL OR a.hr_prog         <= @pHrFim) 
          AND (@pHrEnvioIni      IS NULL OR a.hr_envio        >= @pHrEnvioIni) 
          AND (@pHrEnvioFim      IS NULL OR a.hr_envio        <= @pHrEnvioFim) 
          AND (@pHrRetornoIni    IS NULL OR a.hr_confirmacao  >= @pHrRetornoIni) 
          AND (@pHrRetornoFim    IS NULL OR a.hr_confirmacao  <= @pHrRetornoFim) 
          AND (@pTipoMsg         IS NULL OR a.tp_oper_grid     = @pTipoMsg)
          AND (@DomSPB           IS NULL OR dbo.spb_fc_get_node_value(a.str_xml, 'DomSist') = @DomSPB)
          AND (@pSelicPaga       IS NULL OR @pSelicPaga        = CASE WHEN LEFT(a.cd_msg, 3) = 'SEL' THEN dbo.spb_fc_filtro_oper_paga(a.guid_operacao, a.cd_msg, a.nr_ctrl_if, a.st_operacao, a.dt_movto, DATEADD(d, 5, a.dt_movto))
                                                                      ELSE '0'
                                                                 END)
          AND (@pGrupoMsg        IS NULL OR LEFT(a.cd_msg, 3)  = @pGrupoMsg) 
          AND (@pVlIni           IS NULL OR dbo.spb_fc_vrf_vl_oper_ini(@pDBCR, a.vl_operacao, @pVlIni) = 1) 
          AND (@pVlFim           IS NULL OR dbo.spb_fc_vrf_vl_oper_fim(@pDBCR, a.vl_operacao, @pVlFim) = 1) 
       
       DECLARE cur_status CURSOR READ_ONLY FORWARD_ONLY FOR 
             SELECT DISTINCT
                    a.st_operacao,
                    b.ds_status
               FROM @tab_status            a,
                    spb_tb_gen_status_oper b (NOLOCK)
             WHERE b.st_operacao = a.st_operacao
 
       OPEN cur_status
 
       FETCH NEXT FROM cur_status INTO @st_operacao, @ds_status
       WHILE @@FETCH_STATUS = 0 BEGIN
          SET @str_linha = '<tr>' +
                           '<td>&nbsp;' +
                           '<span style="width:12px;border-style:solid;border-width:0px;border-color:#000000;border-left-width:1px;border-right-width:1px;border-top-width:1px;border-bottom-width:1px;" ' +
                           'class="status_' + CAST(@st_operacao AS varchar(10)) + '">&nbsp;' +
                           '</span>' +
                           '<input type="checkbox" name="Status" value="' + CAST(@st_operacao AS varchar(10)) + '">' + @ds_status +
                           '</td></tr>'
 
          INSERT INTO @tab_retorno ( str_linha) 
                           VALUES (@str_linha)
 
          FETCH NEXT FROM cur_status INTO @st_operacao, @ds_status
       END
 
       CLOSE cur_status
       DEALLOCATE cur_status
 
       RETURN
 
END

