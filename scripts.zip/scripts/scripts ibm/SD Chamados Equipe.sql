
-- dbgerp27sqla\dbgerp27sqla
-- executa dno DBGERP27SQLA\DBGERP27SQLA base MDB

--   use mdb


declare @equipe varchar(100)
declare @dt_ini datetime; declare @dt_fim datetime 
declare @ano char(4) ;  declare @mes char(2);

set @ano = 2012
set @mes = 6

set @dt_ini = @ano + '-' + @mes + '-01 00:00:00.000'
set @dt_fim	= DATEADD(s,-1,DATEADD(mm, DATEDIFF(m,0,@dt_ini)+1,0))

print @dt_fim

set @equipe =  'TI-N3-TC-IBM-dba'


SELECT		dbo.call_req.ref_num AS CHAMADO, 
			(select top 1 isnull(ref_num, '-') from call_req (nolock) cp where cp.persid = call_req.parent) as CHAMADO_PAI,
			ca_contact_2.userid AS [LOGIN], ca_contact_2.last_name AS NOME_COMPLETO, 
            --dbo.usp_contact.zlocalidade AS UNIDADE_AD,
            dbo.usp_contact.zcidade AS CIDADE, dbo.usp_contact.zestrutura AS ESTRUTURA, 
            dbo.usp_contact.zcargo AS CARGO, dbo.usp_contact.zarea AS AREA, dbo.usp_contact.zsubarea AS SUBAREA, 
            DATEADD(ss, dbo.call_req.open_date, '1969-12-31 21:00:00')  AS DATA_ABERTURA,     DATEADD(ss, dbo.call_req.resolve_date, '1969-12-31 21:00:00') AS DATA_SOLUCAO, 
            DATEADD(ss, dbo.call_req.close_date, '1969-12-31 21:00:00') AS DATA_ENCERRAMENTO, DATEADD(ss, dbo.call_req.zprazo, '1969-12-31 21:00:00') AS DATA_PRAZO, 
			DATEDIFF(mi, DATEADD(ss, dbo.call_req.open_date, '1969-12-31 21:00:00'), DATEADD(ss, dbo.call_req.resolve_date, '1969-12-31 21:00:00')  ) TEMPO_SOLUCAO,
            dbo.ca_contact.last_name AS ABERTO_POR, ca_contact_1.last_name AS EQUIPE, ca_contact_3.last_name AS ANALISTA, dbo.prob_ctg.sym AS CATALOGO_SERVICO, 
            dbo.rootcause.sym AS SUBCATALOGO, dbo.srv_desc.sym AS SLA, dbo.cr_stat.z_sym_pt AS STATUS, dbo.call_req.summary as DEMANDA, 
            CASE dbo.call_req.sla_violation WHEN '0' THEN 'No Prazo' ELSE 'Fora do Prazo' END AS ATP,

            CASE WHEN	dbo.call_req.urgency = 0 THEN 'Baixa'  WHEN dbo.call_req.urgency = 1 THEN 'Regular'
            WHEN		dbo.call_req.urgency = 2 THEN 'M�dia'  WHEN dbo.call_req.urgency = 3 THEN 'Alta'
            WHEN		dbo.call_req.urgency = 4 THEN 'Cr�tica' ELSE '' END AS URGENCIA

FROM			dbo.cr_stat (nolock) LEFT JOIN
                dbo.call_req (nolock) LEFT JOIN
                dbo.ca_contact (nolock) ON dbo.call_req.log_agent = dbo.ca_contact.contact_uuid LEFT JOIN
                dbo.rootcause (nolock) ON dbo.call_req.rootcause = dbo.rootcause.id ON dbo.cr_stat.code = dbo.call_req.status  LEFT OUTER JOIN
                dbo.ca_contact AS ca_contact_3 (nolock) ON dbo.call_req.assignee = ca_contact_3.contact_uuid LEFT OUTER JOIN
                dbo.srv_desc (nolock) LEFT JOIN
                dbo.prob_ctg (nolock) ON dbo.srv_desc.code = dbo.prob_ctg.service_type ON dbo.call_req.category = dbo.prob_ctg.persid LEFT OUTER JOIN
                dbo.ca_contact AS ca_contact_2 (nolock) ON dbo.call_req.customer = ca_contact_2.contact_uuid RIGHT OUTER JOIN
                dbo.usp_contact (nolock) ON ca_contact_2.contact_uuid = dbo.usp_contact.contact_uuid LEFT OUTER JOIN
                dbo.ca_contact AS ca_contact_1 (nolock) ON dbo.call_req.group_id = ca_contact_1.contact_uuid

WHERE			ca_contact_1.last_name = @equipe 
					and	DATEADD(ss, open_date, '1969-12-31 21:00:00') > @dt_ini
					and DATEADD(ss, open_date, '1969-12-31 21:00:00') < @dt_fim

-- Filtra apenas os chamados se SQL					
				    and 	  ca_contact_3.last_name in ('Alex Fredrich-N3-IBM-TC', 'Marcos Locateli-N3-IBM-TC', 'Diego Tomiello')
--				    and	  dbo.prob_ctg.sym like 'PT.TI.%Falha%'
order by resolve_date


--  select top 10 * from call_req where ref_num = '2220652' 

--	select top 10 * from call_req where ref_num > 2211694 and urgency > 4

-- global issue 2188510 (pai)   ==> filho: 2188588

/*
summary, description, 

impact, priority   


urgency
0  baixa
1  regular
2  media
3  alta
4  critica




*/