
/*
####################################
script usuarios conectados no banco
####################################
*/

select spid,status,hostname,program_name,cmd,dbid,convert(sysname, rtrim(loginame)) as loginname 
from master.dbo.sysprocesses with (nolock) 

SELECT BancoDados,HoraLogin, sum(TransacoesAbertas) as TransacoesAbertas, Comando, Status,Usuario,Aplicacao,EstacaoTrabalho FROM ( 
Select db_name(dbid) as BancoDados , 
login_time as HoraLogin, 
Open_tran as TransacoesAbertas, 
nt_username as Usuario, 
Hostname as EstacaoTrabalho, 
program_name as Aplicacao, 
Status, 
cmd as Comando 
From master..sysProcesses 
) Tb 
group by BancoDados,HoraLogin, Usuario,Aplicacao,EstacaoTrabalho,Comando,Status 


