
use dba

create table TesteBulkImport (
	id int,
	nome varchar(50)
)

select * from  TesteBulkImport
delete TesteBulkImport

-- drop table TesteBulkImport


BULK INSERT TesteBulkImport
FROM 'C:\Temp\tableToImport.txt'
WITH (firstrow=2,
	FIELDTERMINATOR = ',',
	ROWTERMINATOR='\n'
	--, KEEPNULLS
	);

