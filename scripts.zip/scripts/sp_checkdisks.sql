USE master
GO

/****** Object:  StoredProcedure [dbo].[sp_checkdisks]    Script Date: 22/09/2015 10:41:43 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[sp_checkdisks] (
	@drive nvarchar(512) = '%%',
	@available_gb decimal(16,2) = 99999999.99,
	@order_by varchar(100) = 'Drive'
)
AS
BEGIN

DECLARE @sql nvarchar(max);

DECLARE @version nvarchar(128);
SET @version = CAST(serverproperty('ProductVersion') AS nvarchar);
SET @version = CAST(SUBSTRING(@version, 1, CHARINDEX('.', @version) - 1) as int);
CREATE TABLE #tempdisk (drive nvarchar(512), available_gb decimal(16,2));

IF (@version <= 10) 
	BEGIN 
	---- <= SQL Server 2008R2 ----
	CREATE TABLE #tempdrive
	(
	    Drive CHAR(1) NOT NULL,
	    MbFree INT NOT NULL
	)
	INSERT INTO #tempdrive
		EXEC xp_fixeddrives
	INSERT INTO #tempdisk
		SELECT CAST(Drive as nvarchar(512)) as [Drive], CAST(MbFree/1024 as decimal(16,2)) as [Available GB]
		FROM #tempdrive
	DROP TABLE #tempdrive
	END
ELSE IF (@version >= 11)
	INSERT INTO #tempdisk
   		SELECT DISTINCT 
			volume_mount_point as [Drive],
			CAST(available_bytes/1024/1024/1024 as decimal(16,2))  as [Available GB]
		FROM 
			sys.sysaltfiles CROSS APPLY 
			sys.dm_os_volume_stats(dbid, fileid) ovs
		WHERE filename not LIKE '%mssqlsystemresource%'
		ORDER BY 1
ELSE
   SELECT 'Unsupported SQL Server Version'

SET @sql = '
SELECT drive as [Drive], available_gb as [Available GB] 
FROM #tempdisk 
WHERE 
	drive LIKE ''' + @drive + ''' AND 
	available_gb <= ''' + convert(nvarchar(max), @available_gb) + '''   
ORDER BY ' + @order_by;

EXEC (@sql);
DROP TABLE #tempdisk;

/*** Fim ***/
END

GO