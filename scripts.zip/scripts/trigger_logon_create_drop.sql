CREATE TRIGGER RestrictAccessPerHostname 
ON ALL SERVER
FOR LOGON
AS
BEGIN
IF
(
HOST_NAME() NOT IN ('HostName1','HostName2','HostName3','HostName4','HostName5')
)
BEGIN
RAISERROR('You cannot connect to SQL Server from this machine', 16, 1);
ROLLBACK;
END
END

-- drop trigger RestrictAccessPerHostname on all server

