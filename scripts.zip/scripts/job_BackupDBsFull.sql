USE [msdb]
GO

/****** Object:  Job [BackupDBsFull]    Script Date: 11/09/2015 14:38:54 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 11/09/2015 14:38:54 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'BackupDBsFull', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'SICREDI\rafael_souza', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [BackupDBs]    Script Date: 11/09/2015 14:38:55 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'BackupDBs', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=4, 
		@on_fail_step_id=3, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DECLARE @x SMALLINT
DECLARE @Quant SMALLINT
DECLARE @Command VARCHAR(8000)
DECLARE @BackupType VARCHAR(6)
DECLARE @CopyOnly CHAR(1)
DECLARE @BackupRepositoryPath VARCHAR(200)
DECLARE @Compression CHAR(1)
DECLARE @Name VARCHAR(60)
DECLARE @Exclude VARCHAR(200)

SET @x = 0
SET @BackupType=''FULL''
SET @CopyOnly=''0''
SET @BackupRepositoryPath=''\\sistemas01\backup_mssql\''+@@SERVERNAME+''\MSSQLSERVER\BackupFull\''
SET @Compression=''1''
SET @Exclude=''mdb''

DECLARE VCursor CURSOR STATIC FOR
	SELECT Name
	FROM sys.databases
	WHERE state=0 AND is_read_only = 0 AND name NOT IN (''model'',''tempdb'') AND name NOT IN (@Exclude)

OPEN VCursor
FETCH NEXT FROM VCursor INTO @Name

WHILE @@FETCH_STATUS = 0
BEGIN
	SELECT @Command= ''EXEC [dbo].[Backup] @DB=''''''+@Name+'''''', @BackupType=''''''+@BackupType+'''''', @CopyOnly=''+@CopyOnly+'', @BackupRepositoryPath=''''''+@BackupRepositoryPath+'''''', @Compression=''+@Compression+''''
	EXEC (@Command)
	--PRINT @Command
	FETCH NEXT FROM VCursor INTO @Name
END

CLOSE VCursor
DEALLOCATE VCursor', 
		@database_name=N'master', 
		@output_file_name=N'C:\SQL\Logs\JOB_BackupDBsFull_Step_BackupDBs.log', 
		@flags=4
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [ArchiveFiles]    Script Date: 11/09/2015 14:38:55 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'ArchiveFiles', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=4, 
		@on_fail_step_id=3, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'CmdExec', 
		@command=N'CALL SET BackupPath=\\sistemas01\backup_mssql\%ComputerName%\MSSQLSERVER\BackupFull\ && CALL C: && CALL cd "\program files\tivoli\tsm\baclient\" && CALL "\program files\tivoli\tsm\baclient\dsmc.exe" archive -del -archmc=mc_mssql_30d %BackupPath% >> C:\SQL\Logs\JOB_BackupDBsFull_Step_ArchiveFiles.log', 
		@flags=32
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [SendTrapOnError]    Script Date: 11/09/2015 14:38:55 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'SendTrapOnError', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=2, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec dba.dbo.sysedge_gera_trap_V2 @subject=''Falha no job de backup full''', 
		@database_name=N'DBA', 
		@output_file_name=N'C:\SQL\Logs\JOB_BackupDBsFull_Step_SendTrapOnError.log', 
		@flags=2
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Schedule', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20110615, 
		@active_end_date=99991231, 
		@active_start_time=100000, 
		@active_end_time=235959, 
		@schedule_uid=N'b9f57926-6f17-4750-878b-9f72374e1d8a'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO


