
use EvolutionPro
go

-- pendente monitor de fraudes
select count(*) as Total 
from evolutionpro..spb_tb_pil_operacoes 
where dt_movto = (SELECT CONVERT (date, SYSDATETIME())) and st_operacao = '2001'

-- pendentes Monitor de Fraudes Detalhado
 select EvolutionPro.dbo.spb_fc_get_node_value(str_xml,'CodMsg') AS [CODMSG],
    EvolutionPro.dbo.spb_fc_get_node_value(str_xml,'NumCtrlIF') AS [NUMCTRLIF],
    --EvolutionPro.dbo.dt_hr_entrada AS [DT_HR_ENTRADA],
    EvolutionPro.dbo.spb_fc_get_node_value(str_xml,'AgDebtd') AS [AGDEBTD],
    EvolutionPro.dbo.spb_fc_get_node_value(str_xml,'CtDebtd') AS [CTDEBTD],
    EvolutionPro.dbo.spb_fc_get_node_value(str_xml,'VlrLanc') AS [VLRLANC],
    case
        when NR_CTRL_IF LIKE 'DG%' then 'Digital'
        when NR_CTRL_IF LIKE 'EVO%' then 'Manual(Evolution)'
        else 'Legado'
    end AS [ORIGEM]
from evolutionpro..spb_tb_pil_operacoes 
where dt_movto = CONVERT (date, SYSDATETIME())
and st_operacao = '2001'
