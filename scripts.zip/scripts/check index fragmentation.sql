
--sp_whoisactive @get_plans = 1
SELECT  
t.name 'TableName',
i.name 'IndexName',
frag.avg_fragmentation_in_percent 'Percent Fragmented',
frag.page_count,
(frag.page_count * 8 / 1024) index_mb,
'ALTER INDEX ' + i.name + ' ON ' + t.name + ' REBUILD WITH (ONLINE=ON, MAXDOP=8)' AS Command
FROM    sys.dm_db_index_physical_stats (DB_ID(), NULL, NULL, NULL, NULL) frag
JOIN    sys.tables t ON frag.object_id = t.object_id
JOIN    sys.indexes i ON frag.index_id = i.index_id AND frag.object_id = i.object_id
WHERE   frag.page_count > 1000
AND     frag.avg_fragmentation_in_percent > 20
AND i.type != 0
AND t.name != 'ThreadActionCount'
--AND t.name IN ('')
ORDER BY frag.avg_fragmentation_in_percent DESC
OPTION(RECOMPILE, MAXDOP 4)

--alter index ixPropostas_Validas on PROPOSTAS_VALIDAS rebuild with (online=on)

