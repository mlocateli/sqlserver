
--create master key encryption by password = 'senha'

--create certificate Agenda
--with subject = 'CertificadoAgenda'

--create symmetric key sk_agenda with algorithm = Triple_DES encryption
--by certificate Agenda

--a coluna com os dados criptografados tem que ser varbinary
--create table agenda
--  (testeEnc varbinary(300))

--open symmetric key sk_agenda decryption by certificate Agenda

select *
from agenda

insert into agenda
values (encryptbykey(key_guid('sk_agenda'),'teste um'))

select convert(varchar, decryptbykey(testeEnc)) as testeEnc
from agenda

CLOSE SYMMETRIC KEY sk_agenda

create view vwAgenda
as
select convert(varchar, decryptbykey(testeEnc)) as testeEnc
from agenda

select *
from vwAgenda