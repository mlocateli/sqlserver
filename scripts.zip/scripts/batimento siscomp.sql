
-- consulta batimento siscomp

use siscomp
go

select AGENCIADEST from DOC_SR a
left JOIN PAC b ON a.AGENCIADEST=b.AG_PA
where b.AG_PA is null 

