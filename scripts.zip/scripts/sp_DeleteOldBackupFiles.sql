
USE master
GO

CREATE OR ALTER PROCEDURE [dbo].[sp_DeleteOldBackupFiles] @path NVARCHAR(256),
	@extension NVARCHAR(10),
	-- @age_hrs INT
	@age int -- altered from hrs to days
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @DeleteDate NVARCHAR(50)
	DECLARE @DeleteDateTime DATETIME

	-- SET @DeleteDateTime = DateAdd(hh, - @age_hrs, GetDate())
	SET @DeleteDateTime = DateAdd(dd, - @age, GetDate()) -- altered from hrs to days

        SET @DeleteDate = (Select Replace(Convert(nvarchar, @DeleteDateTime, 111), '/', '-') + 'T' + Convert(nvarchar, @DeleteDateTime, 108))

	-- SELECT @path, @extension, @DeleteDate

	EXECUTE master.dbo.xp_delete_file 0,
		@path,
		@extension,
		@DeleteDate,
		1
END

-- @path, @file_extension, @age -- (in days), @age_hrs
exec sp_DeleteOldBackupFiles 'd:\backup', 'bak', 7

