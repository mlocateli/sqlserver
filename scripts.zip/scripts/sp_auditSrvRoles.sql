CREATE PROCEDURE sp_auditSrvRoles
AS

/*** Seleciona os usuários e as permissões deles a nível de instância ***/
DECLARE @sql nvarchar(max)
SET @sql = '
with ServerPermsAndRoles as
(
    select
		CASE spr.is_disabled    
		WHEN 0 THEN ''Enabled''
		ELSE ''Disabled''   
		END AS status,
        spr.name as principal_name,
        spr.type_desc as principal_type,
        spm.permission_name collate SQL_Latin1_General_CP1_CI_AS as security_entity,
        ''permission'' as security_type,
        spm.state_desc
    from sys.server_principals spr
    inner join sys.server_permissions spm
    on spr.principal_id = spm.grantee_principal_id
    where spr.type not in (''A'', ''R'', ''C'', ''K'')

    union all

    select
        CASE sp.is_disabled    
		WHEN 0 THEN ''Enabled''
		ELSE ''Disabled''   
		END AS status,
		sp.name as principal_name,
        sp.type_desc as principal_type,
        spr.name as security_entity,
        ''role membership'' as security_type,
        null as state_desc
    from sys.server_principals sp
    inner join sys.server_role_members srm
    on sp.principal_id = srm.member_principal_id
    inner join sys.server_principals spr
    on srm.role_principal_id = spr.principal_id
    where sp.type not in (''A'', ''R'', ''C'', ''K'') 
)
select *
from ServerPermsAndRoles
where principal_name not in (''dbo'', ''public'', ''##MS_PolicyEventProcessingLogin##'', ''##MS_PolicyTsqlExecutionLogin##'', ''NT AUTHORITY\SYSTEM'', ''NT SERVICE\MSSQLSERVER'', ''NT SERVICE\SQLSERVERAGENT'') 
order by principal_name'

EXEC(@sql)

/*** Fim ***/
GO
