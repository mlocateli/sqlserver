CREATE PROCEDURE sp_audit (@db varchar(200) = NULL)
AS

/*** Verifica o collation para evitar erros no join entre database_principals e server_principals ***/
DECLARE @Collation as SYSNAME
SET @Collation = cast(DATABASEPROPERTYEX('Tempdb', 'Collation') as nvarchar)

/*** Seleciona os usuários e as roles que foram dadas a eles no banco ***/
DECLARE @sql nvarchar(max)
SET @sql = 'use '+ISNULL(@db, db_name(db_id()))+' 
SELECT 
       DISTINCT 
       CASE sp.is_disabled    
       WHEN 0 THEN ''Enabled''
       ELSE ''Disabled''
       END AS status,
       mp.type_desc as db_user_type,
       mp.name AS db_user, 
       rp.name AS db_role_member
FROM sys.database_role_members rm
       join sys.database_principals mp on (rm.member_principal_id = mp.principal_id)
       join sys.database_principals rp on (rm.role_principal_id = rp.principal_id)
       join sys.server_principals sp on (mp.name COLLATE '+ @Collation +' = sp.name)
WHERE mp.name not in (''dbo'', ''public'') 
       and mp.type not in (''A'', ''R'', ''C'', ''K'')
       /** A=App role, R=Database role, C=User mapped to a certificate, K = User mapped to an asymmetric key **/
ORDER BY status, db_user_type, db_user'
EXEC(@sql)

/*** Seleciona os usuários e as permissões deles nos objetos do banco ***/
DECLARE @sql2 nvarchar(max)
SET @sql2 = 'use '+ISNULL(@db, db_name(db_id()))+' 
SELECT 
	CASE sp.is_disabled    
	WHEN 0 THEN ''Enabled''
	ELSE ''Disabled''   
	END AS status,
	su.name as db_user, 
	so.name as db_object,  
	dp.state_desc as permission_type,
	dp.permission_name as permission
FROM sys.database_permissions dp
	join sys.sysusers su on (dp.grantee_principal_id = su.uid)
	join sys.sysobjects so on (dp.major_id = so.id)
	join sys.server_principals sp on (su.name COLLATE '+ @Collation +' = sp.name)
WHERE sp.name not in (''dbo'', ''public'') 
	and sp.type not in (''A'', ''R'', ''C'', ''K'')
ORDER BY su.name '
EXEC(@sql2)

/*** Verifica os usuários órfãos do banco de dados (sem login mapeado) ***/
DECLARE @sql3 nvarchar(max)
SET @sql3 = '
sp_change_users_login @Action=''Report'' '
EXEC(@sql3)

/*** Seleciona os usuários e as permissões deles a nível de instância ***/
DECLARE @sql4 nvarchar(max)
SET @sql4 = '
with ServerPermsAndRoles as
(
    select
		CASE spr.is_disabled    
		WHEN 0 THEN ''Enabled''
		ELSE ''Disabled''   
		END AS status,
        spr.name as principal_name,
        spr.type_desc as principal_type,
        spm.permission_name collate SQL_Latin1_General_CP1_CI_AS as security_entity,
        ''permission'' as security_type,
        spm.state_desc
    from sys.server_principals spr
    inner join sys.server_permissions spm
    on spr.principal_id = spm.grantee_principal_id
    where spr.type not in (''A'', ''R'', ''C'', ''K'')

    union all

    select
        CASE sp.is_disabled    
		WHEN 0 THEN ''Enabled''
		ELSE ''Disabled''   
		END AS status,
		sp.name as principal_name,
        sp.type_desc as principal_type,
        spr.name as security_entity,
        ''role membership'' as security_type,
        null as state_desc
    from sys.server_principals sp
    inner join sys.server_role_members srm
    on sp.principal_id = srm.member_principal_id
    inner join sys.server_principals spr
    on srm.role_principal_id = spr.principal_id
    where sp.type not in (''A'', ''R'', ''C'', ''K'') 
)
select *
from ServerPermsAndRoles
where principal_name not in (''dbo'', ''public'', ''##MS_PolicyEventProcessingLogin##'', ''##MS_PolicyTsqlExecutionLogin##'', ''NT AUTHORITY\SYSTEM'', ''NT SERVICE\MSSQLSERVER'', ''NT SERVICE\SQLSERVERAGENT'') 
order by principal_name'
EXEC(@sql4)

/*** Fim ***/
GO