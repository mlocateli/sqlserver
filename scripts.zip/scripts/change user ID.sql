http://www.planet-source-code.com/vb/scripts/ShowCode.asp?txtCodeId=408&lngWId=5
/*
You can effectively rename a user account but as this is messing with the system tables 
I would suggest dropping and adding the user back. But for those of you who really want to know how here it is.

First off I tested this and it works fine renaming a user. 

However this is directly modifying the system tables and setting the configuration to do this. 

I make no guarantees that you could not possible cause yourself an issue. 

And if you do make these kinds of changes they are yours to deal with if failure occurrs.

Note:
I did find out that you can do this while the user is logged in. 
They just will have to use the new login name after they logout and come back. 
Also you will need to be a member of the server admin role to run this. 

Thru testing the following results occurr:
In the case of objects owned by a renamed user. 
The owner name changes automatically. If any of the owned objects specify an owned object 
(in the format Owner.Object) and the Owner is the one that was renamed these will have to be 
rebuilt/altered with the correct owner replacements. Otherwise views, procedures, and tables roll over fine. 
Triggers fell into the category of Owner.Object being reference internal and had to be altered.

Ex. usp_RenameLogin 'Test', 'TestLogin'
*/
---Code should be put in master database---
--for SQL 2005

/*
Alterando nome do usu�rio no SQL Server

Para alterar o nome de um usu�rio no SQL Server 2000
*/

USE master
GO

CREATE PROCEDURE usp_RenameLogin
@CurrentLogin	sysname,
@NewLogin	sysname
AS

DECLARE @SQLState AS VARCHAR(200)

--Configure server to allow ad hoc updates to system tables
EXEC master.dbo.sp_configure 'allow updates', '1'
RECONFIGURE WITH OVERRIDE

--Update user login name in master db
SET @SQLState = 'UPDATE master.dbo.sysxlogins SET [name] = ''' + @NewLogin + ''' WHERE [name] = ''' + @CurrentLogin + ''''
EXEC (@SQLState)

--Update user login name in each db where has access as in in sysusers table
SET @SQLState = 'EXEC master.dbo.sp_MSForEachDB ''UPDATE ?.dbo.sysusers SET [name] = ''''' + @NewLogin + ''''' where [name] = ''''' + @CurrentLogin + ''''''''
EXEC (@SQLState)

--Configure server to disallow ad hoc--updates to system tables
EXEC master.dbo.sp_configure 'allow updates', '0'
RECONFIGURE WITH OVERRIDE
GO

--After execute the command
EXEC usp_RenameLogin 'old_user', 'new_user'


/*
Alterando username no SQL Server


*/
--for SQL 2000

--habilita update nas tabelas do sistema
EXEC master.dbo.sp_configure 'allow updates', '1'
RECONFIGURE WITH OVERRIDE
GO

DECLARE @user VARCHAR(20)
DECLARE @newuser VARCHAR(20)

SET @user = 'user'
SET @newuser = 'newuser'

USE master
GO

--Altera username do SQL Server
UPDATE master.dbo.sysxlogins SET [name] = @newuser WHERE [name] = @user
GO

--Altera username da database
USE <database_name>
GO

UPDATE sysusers SET [name] = @newuser where [name] = @user
GO

--desabilita altera��o das tabelas de sistema
EXEC master.dbo.sp_configure 'allow updates', '0'
RECONFIGURE WITH OVERRIDE
GO

--PARA SQL SERVER 2005/2008
DECLARE @user VARCHAR(20)
DECLARE @newuser VARCHAR(20)

SET @user = 'user'
SET @newuser = 'newuser'

--altera username do SQL Server
USE master
ALTER LOGIN @user WITH NAME = @newuser
GO

--altera username da database
USE <database_name>
ALTER USER @user WITH NAME = @newuser
GO 
 
--para todas as databases voce pode usar
--EXEC master.dbo.sp_MSForEachDB 'ALTER USER @user WITH NAME = @newuser'