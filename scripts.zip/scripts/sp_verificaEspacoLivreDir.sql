/*** Verifica espaço livre em um diretório \\sistemas01\... e gera um alerta caso esteja com menos de 50bytes livre ***/

USE [DBA]
GO

/****** Object:  StoredProcedure [dbo].[VerificaEspacoLivre]    Script Date: 19/08/2015 10:01:12 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[VerificaEspacoLivre]
AS
BEGIN

	SET NOCOUNT ON
	DECLARE @tbhelper AS TABLE ([output] VARCHAR(1000))
	DECLARE @FreeSpace AS INT

	INSERT INTO @tbhelper
	EXEC xp_cmdshell 'dir \\sistemas01\backup_mssql\ | findstr "free"'

	SELECT @FreeSpace = 
		CAST(REPLACE(REPLACE(RIGHT([output], (LEN([output]) - CHARINDEX('(s)', [output]) - 2)), 'bytes free', ''), ',', '') AS BIGINT) / 1073741824
	FROM @tbhelper 
		WHERE [output] LIKE '%bytes disponíveis%' OR [output] LIKE '%bytes free%'

	IF (@FreeSpace < 50)
	BEGIN
		EXEC dba.dbo.[sysedge_gera_trap_V2] @subject='backup_mssql no sistema01 esta cheio'
	END
	
END
GO


