
-- alter authorization
-- alter database owner db_owner 

ALTER AUTHORIZATION ON DATABASE::mdb TO [SICREDI\app_sqlcore];
GO


