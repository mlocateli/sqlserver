
-- evolutionpro
-- roteador de TEDs

Use evolutionpro;
Go

update spb_tb_leg_protocolos
set dt_hr_entrada = getdate(),
dt_hr_envio = null,
flg_enviar = 'S',
flg_proc_util = 'N',
dt_hr_lock = '1900-01-01',
guid_lock = '00000000-0000-0000-0000-000000000000'
-- ajustar o TOP conforme o nro de TEDs desejadas
where guid_operacao in (select top 10 guid_operacao
from spb_tb_pil_operacoes (nolock)
where dt_movto = '2020-03-16'
and left(cd_msg, 3) in ('PAG', 'STR')
and cd_msg like '%08R2')
and id_fila = 55
