
/*
Lendo os arquivos de log do SQL Server

--http://www.mssqltips.com/sqlservertip/1476/reading-the-sql-server-log-files-using-tsql/
*/

CREATE PROC [sys].[sp_readerrorlog](
   @p1     INT = 0,
   @p2     INT = NULL,
   @p3     VARCHAR(255) = NULL,
   @p4     VARCHAR(255) = NULL)
AS
BEGIN

   IF (NOT IS_SRVROLEMEMBER(N'securityadmin') = 1)
   BEGIN
      RAISERROR(15003,-1,-1, N'securityadmin')
      RETURN (1)
   END
   
   IF (@p2 IS NULL)
       EXEC sys.xp_readerrorlog @p1
   ELSE
       EXEC sys.xp_readerrorlog @p1,@p2,@p3,@p4
END

/*
This procedure takes four parameters:

    Value of error log file you want to read: 0 = current, 1 = Archive #1, 2 = Archive #2, etc...
    Log file type: 1 or NULL = error log, 2 = SQL Agent log
    Search string 1: String one you want to search for
    Search string 2: String two you want to search for to further refine the results

If you do not pass any parameters this will return the contents of the current error log.
*/

--Example 1
EXEC sp_readerrorlog 6

--Example 2
EXEC sp_readerrorlog 6, 1, '2005'

--Example 3
EXEC sp_readerrorlog 6, 1, '2005', 'exec'

/*
xp_readerrrorlog

Even though sp_readerrolog accepts only 4 parameters, the extended stored procedure accepts at least 7 parameters.

If this extended stored procedure is called directly the parameters are as follows:

    Value of error log file you want to read: 0 = current, 1 = Archive #1, 2 = Archive #2, etc...
    Log file type: 1 or NULL = error log, 2 = SQL Agent log
    Search string 1: String one you want to search for
    Search string 2: String two you want to search for to further refine the results
    Search from start time  
    Search to end time
    Sort order for results: N'asc' = ascending, N'desc' = descending
*/

--Examples
EXEC master.dbo.xp_readerrorlog 6, 1, '2005', 'exec', NULL, NULL, N'desc'
EXEC master.dbo.xp_readerrorlog 6, 1, '2005', 'exec', NULL, NULL, N'asc'



