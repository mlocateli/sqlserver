
/****** Object:  StoredProcedure [dbo].[spu_db_optimization]    Script Date: 10/24/2013 09:50:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
    
        
CREATE procedure [dbo].[spu_db_optimization](@maxfrag decimal = 10, @mindens decimal = 70) as        
        
set arithabort on        
set quoted_identifier on        
        
print char(13)        
print '-- *************************************************************************************** ' + char(13)        
print '-- *************************************************************************************** ' + char(13)        
print '--  OPTIMIZING DATABASE: ' + db_name() + ' - ' + convert(varchar(30), getdate(), 13) + char(13)        
print '-- *************************************************************************************** ' + char(13)        
print '-- *************************************************************************************** ' + char(13)        
        
set nocount on        
declare @dbreindex varchar(500), @updateusage varchar(500), @statistics varchar(500), @sp_recompile varchar(500)        
declare @owner_tabela varchar(250), @nome_tabela varchar(250), @indice_nome varchar(250)        
declare @linha int, @total int, @indexid int, @linha2 int, @total2 int        
declare @logicalfrag decimal, @scandensity decimal        
--declare @maxfrag decimal, @mindens decimal        
--set @maxfrag = 10        
--set @mindens = 70        
        
if exists(select name from tempdb..sysobjects where name like '#tabelas_showcontig_%' and type = 'U')         
   begin        
      drop table #tabelas_showcontig_final        
   end        
if exists(select name from tempdb..sysobjects where name like '#objetos_%' and type = 'U')         
   begin        
      drop table #objetos_final        
   end        
if exists(select name from tempdb..sysobjects where name like '#tabelas_showcontig%' and type = 'U')         
   begin        
      drop table #tabelas_showcontig        
   end        
if exists(select name from tempdb..sysobjects where name like '#objetos%' and type = 'U')         
   begin        
      drop table #objetos        
   end        
        
create table #tabelas_showcontig (        
   owner_tabela char(255),        
   objectname char (255),        
   objectid int,        
   indexname char (255),        
   indexid int,        
   lvl int,        
   countpages int,        
   countrows int,        
   minrecsize int,        
   maxrecsize int,        
   avgrecsize int,        
   forreccount int,        
   extents int,        
   extentswitches int,        
   avgfreebytes int,        
   avgpagedensity int,        
   scandensity decimal,        
   bestcount int,        
   actualcount int,        
   logicalfrag decimal,        
   extentfrag decimal        
)        
        
create table #objetos (        
   owner_tabela varchar(150),        
   nome_tabela varchar(150)        
)        
        
-- somente tabelas que possuam fndices        
-- tabelas de usu�rio - type = 'u' (user table)        
-- i.indid: 1 = Clustered index, >1 Nonclustered e 255 = Entry for tables that have text or image data        
insert #objetos         
select OBJECT_SCHEMA_NAME(o.id) owner, o.name tabela     
from dbo.sysobjects o inner join sysindexes i on o.id = i.id        
where upper(type) = 'U' and i.status > 0 and upper(i.name) not like '_WA%'        
group by OBJECT_SCHEMA_NAME(o.id), o.name order by 1, 2        
        
-- cria campo ordem para realizar o loop        
select identity(int, 1,1) as ordem, * into #objetos_final from #objetos        
        
-- prepara variaveis para loop        
select @linha = 1, @total = max(ordem) from #objetos_final        
        
while (@linha <= @total)        
   begin        
        
      select @owner_tabela = owner_tabela, @nome_tabela = nome_tabela from #objetos_final where ordem = @linha        
            insert into #tabelas_showcontig (objectname, objectid, indexname, indexid, lvl, countpages, countrows, minrecsize, maxrecsize, avgrecsize, forreccount, extents, extentswitches, avgfreebytes, avgpagedensity, scandensity, bestcount, actualcount,
     
      
 logicalfrag, extentfrag)        
     exec ('dbcc showcontig (''[' + @owner_tabela + '].[' + @nome_tabela + ']'')  with fast, tableresults, all_indexes, no_infomsgs')        
     update #tabelas_showcontig set owner_tabela = @owner_tabela where owner_tabela is null or owner_tabela = ''        
      set @linha = @linha + 1        
   end        
        
-- Apaga indices de campos text, etc        
delete #tabelas_showcontig where indexid >= 255         
        
-- Elimina registros que npo estpo fragmentados        
delete #tabelas_showcontig where logicalfrag < @maxfrag or scandensity >= @mindens        
        
-- cria campo ordem para realizar o loop        
select identity(int, 1,1) as ordem, * into #tabelas_showcontig_final from #tabelas_showcontig        
        
-- prepara variaveis para loop        
select @linha2 = 1, @total2 = max(ordem) from #tabelas_showcontig_final        
        
while (@linha2 <= @total2)        
   begin        
        
      select @indexid = indexid, @owner_tabela = rtrim(owner_tabela), @nome_tabela = rtrim(objectname),         
         @indice_nome = rtrim(indexname), @logicalfrag = logicalfrag, @scandensity = scandensity         
         from #tabelas_showcontig_final where ordem = @linha2        
              
        
         print char(13)        
         print '-- *************************************************************************************** ' + char(13)        
         print '--  TABLE: ' + rtrim(@nome_tabela) + ' - INDEX: ' + rtrim(@indice_nome) + ' - ' + convert(varchar(30), getdate(), 13) + '' + char(13)         
         print '--  LOGICAL FRAGMENTATION: ' + rtrim(convert(varchar(10), @logicalfrag)) + char(13)         
         print '--  SCAN DENSITY: ' + rtrim(convert(varchar(10), @scandensity)) + char(13)         
         print '-- *************************************************************************************** ' + char(13)        
        
         if @indexid = 0        
            begin        
               set @dbreindex = 'dbcc dbreindex(' + '''[' +  @owner_tabela + '].[' + @nome_tabela + ']''' + ')'        
               set @updateusage = 'dbcc updateusage ([' + db_name() + '],''['+ @owner_tabela + '].[' + @nome_tabela + ']'')'        
               set @statistics = 'update statistics [' + @owner_tabela + '].' + @nome_tabela        
            end        
         else        
            begin        
               set @dbreindex = 'dbcc dbreindex(' + '''[' + @owner_tabela  + '].[' + @nome_tabela + ']''' +  ',[' +  @indice_nome + '])'         
               set @updateusage = 'dbcc updateusage ([' + db_name() + '],''['+ @owner_tabela + '].[' + @nome_tabela + ']'', ' + '''' + @indice_nome + '''' + ')'        
               set @statistics = 'update statistics [' + @owner_tabela + '].[' + @nome_tabela + '](' + @indice_nome + ') with fullscan'        
         end        
        
         print @dbreindex        
         exec(@dbreindex)        
        
         print @updateusage        
         exec(@updateusage)        
        
         print @statistics        
         exec(@statistics)        
        
         if (((select rtrim(objectname) from #tabelas_showcontig_final where ordem = @linha2+1) <> @nome_tabela) or        
            (@linha2 = @total2))        
            begin        
               print 'sp_recompile ''[' + @owner_tabela + '].[' + @nome_tabela + ']'''        
               exec('sp_recompile ''[' + @owner_tabela + '].[' + @nome_tabela + ']''')        
            end        
        
         set @linha2 = @linha2 + 1        
        
   end        
        
        
print char(13)        
print '-- *************************************************************************************** ' + char(13)        
print '-- *************************************************************************************** ' + char(13)        
print '--  FINISHING REINDEX ON DATABASE ' + db_name() + ' - ' + convert(varchar(30), getdate(), 13) + char(13)        
print '-- *************************************************************************************** ' + char(13) + char(13)        
print '-- *************************************************************************************** ' + char(13)        
        