-- MONITORING TRANSACTION LOG
-- monitora quem está consumindo o LOG
-- http://sqlworldwide.com/what-is-consuming-my-log-space/

INSERT INTO DBA.dbo.logUsageMonitor
SELECT DB_NAME(tdt.database_id) AS [dbName] ,
  (tdt.database_transaction_log_bytes_reserved
  + tdt.database_transaction_log_bytes_used
  + tdt.database_transaction_log_bytes_used_system
  + tdt.database_transaction_log_bytes_reserved_system ) / 1024 AS [tlogUsedKB] ,
  tst.session_id ,
  CONVERT(TIME(2), ( GETDATE() - tdt.database_transaction_begin_time )) AS [durInLog hh:mm:ss] ,
  t.text ,
  [statement] =
  COALESCE(NULLIF(SUBSTRING(t.text,r.statement_start_offset / 2,
  CASE
    WHEN r.statement_end_offset < r.statement_start_offset
      THEN 0
    ELSE ( r.statement_end_offset - r.statement_start_offset ) / 2
    END), ''), t.text), getdate() as Collection_Time
-- INTO DBA.dbo.logUsageMonitor
FROM  sys.dm_tran_database_transactions AS tdt
INNER JOIN sys.dm_tran_session_transactions AS tst ON tdt.transaction_id = tst.transaction_id
LEFT OUTER JOIN sys.dm_exec_requests AS r ON tst.session_id = r.session_id
OUTER APPLY sys.dm_exec_sql_text(r.plan_handle) AS t
WHERE  tdt.database_transaction_log_bytes_used > 0
AND (tdt.database_transaction_log_bytes_reserved
  + tdt.database_transaction_log_bytes_used
  + tdt.database_transaction_log_bytes_used_system
  + tdt.database_transaction_log_bytes_reserved_system ) / 1024 > 0
AND tdt.database_transaction_log_bytes_used > 0
ORDER BY tlogUsedKB DESC;

SELECT *
FROM DBA.dbo.logUsageMonitor
WHERE dbName = 'JDNPC'
order by tlogUsedKB desc, collection_time

