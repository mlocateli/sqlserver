USE [master]
GO

/****** Object:  UserDefinedFunction [dbo].[fn_database_is_read_write]    Script Date: 30/09/2015 10:34:27 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE FUNCTION [dbo].[fn_database_is_read_write] (@db_name sysname)
RETURNS BIT
AS
BEGIN
DECLARE
	@db_state TINYINT,
	@role TINYINT

	SELECT 
		@db_state = db.state, @role = hars.role
	FROM 
		sys.databases db
		LEFT JOIN sys.dm_hadr_availability_replica_states hars ON db.replica_id = hars.replica_id
	WHERE 
		db.name = @db_name

	IF @db_state = 0 /* ONLINE */AND (@role = 1 /* PRIMARY */ OR @role IS NULL /* NOT IN AVG */ )
	BEGIN
		RETURN 1
	END
	ELSE
	BEGIN
		--force RAISERROR
		RETURN CAST('This database is read-only!' AS INT);
		RETURN 0
	END
	RETURN 0
END
GO
