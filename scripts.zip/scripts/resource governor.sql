
-- Obtain the resource pool and workload group configuration

USE master;  
SELECT * FROM sys.resource_governor_resource_pools;  
SELECT * FROM sys.resource_governor_workload_groups;  
GO  

--- Get the classifier function Id and state (enabled).  
SELECT * FROM sys.resource_governor_configuration;  
GO 

--- Get the classifer function name and the name of the schema  
--- that it is bound to.  
SELECT   
      object_schema_name(classifier_function_id) AS [schema_name],  
      object_name(classifier_function_id) AS [function_name]  
FROM sys.dm_resource_governor_configuration;  

-- Find out what sessions are in each group
SELECT s.group_id, CAST(g.name as nvarchar(20)), s.session_id, s.login_time, 
    CAST(s.host_name as nvarchar(20)), CAST(s.program_name AS nvarchar(20))  
FROM sys.dm_exec_sessions AS s  
INNER JOIN sys.dm_resource_governor_workload_groups AS g  
    ON g.group_id = s.group_id  
ORDER BY g.name;  
GO  

-- Find out which requests are in each group
SELECT r.group_id, g.name, r.status, r.session_id, r.request_id, 
    r.start_time, r.command, r.sql_handle, t.text   
FROM sys.dm_exec_requests AS r  
INNER JOIN sys.dm_resource_governor_workload_groups AS g  
    ON g.group_id = r.group_id  
CROSS APPLY sys.dm_exec_sql_text(r.sql_handle) AS t  
ORDER BY g.name;  
GO  

-- Find out what requests are running in the classifier
SELECT s.group_id, g.name, s.session_id, s.login_time, s.host_name, s.program_name   
FROM sys.dm_exec_sessions AS s  
INNER JOIN sys.dm_resource_governor_workload_groups AS g  
    ON g.group_id = s.group_id  
       AND 'preconnect' = s.status  
ORDER BY g.name;  
GO  

SELECT r.group_id, g.name, r.status, r.session_id, r.request_id, r.start_time, 
    r.command, r.sql_handle, t.text   
FROM sys.dm_exec_requests AS r  
INNER JOIN sys.dm_resource_governor_workload_groups AS g  
    ON g.group_id = r.group_id  
       AND 'preconnect' = r.status  
 CROSS APPLY sys.dm_exec_sql_text(r.sql_handle) AS t  
ORDER BY g.name;  
GO  


USE [master]
GO

-- create a resource pool
CREATE RESOURCE POOL [db0mbam1p] WITH(min_cpu_percent=0, 
		max_cpu_percent=40, 
		min_memory_percent=0, 
		max_memory_percent=60, 
		cap_cpu_percent=10, 
		AFFINITY SCHEDULER = AUTO
, 
		min_iops_per_volume=0, 
		max_iops_per_volume=0)

GO

-- create a workload group
CREATE WORKLOAD GROUP [db0mbam1p] WITH(group_max_requests=60, 
		importance=Medium, 
		request_max_cpu_time_sec=0, 
		request_max_memory_grant_percent=25, 
		request_memory_grant_timeout_sec=0, 
		max_dop=0)
GO

-- create classifier function
CREATE OR ALTER FUNCTION [dbo].[fn_ResourceGovernorClassifier]()          
RETURNS sysname          
WITH SCHEMABINDING          
AS          
BEGIN          
 DECLARE @group sysname          
 SET @group = 'default'          
 --Workload group is case sensitive          
 --Logins List          
 IF SUSER_NAME() IN ('app_epo510')          
  SET @group = 'db0epo1p'          
     
  IF SUSER_NAME() IN ('SICREDI\mbam-DB-RW')          
  SET @group = 'db0mbam1p'  

 RETURN @group          
END 


-- Set the classifier function for Resource Governor
ALTER RESOURCE GOVERNOR 
WITH ( 	CLASSIFIER_FUNCTION = dbo.fn_ResourceGovernorClassifier);
GO

-- Disable Resource Governor
ALTER RESOURCE GOVERNOR 
WITH ( 	CLASSIFIER_FUNCTION = NULL);
GO

ALTER RESOURCE GOVERNOR DISABLE;
GO

-- Make changes effective
ALTER RESOURCE GOVERNOR RECONFIGURE
GO

