
sp_requests @database = 'CompeEzCheck'

sp_sessions @database = 'CompeEzCheck'

sp_whoisactive @help=1

sp_whoisactive @filter_type='login', @filter = 'app_compeimagem'

