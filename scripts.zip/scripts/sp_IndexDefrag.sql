CREATE TABLE dba.dbo.IndexDefragHistory 
	(
	DBName NVARCHAR(255)
	,TableName NVARCHAR(255)
	,SchemaName NVARCHAR(255)
	,IndexName NVARCHAR(255)
	,AvgFrag DECIMAL
	)
GO

CREATE PROCEDURE master.dbo.sp_IndexDefrag
AS

DECLARE 
	@DBName NVARCHAR(255)
	,@TableName NVARCHAR(255)
	,@SchemaName NVARCHAR(255)
	,@IndexName NVARCHAR(255)
	,@AvgFrag DECIMAL

DECLARE @Defrag NVARCHAR(MAX)

EXEC sp_msforeachdb
'INSERT INTO dba.dbo.IndexDefragHistory (
	DBName, 
	TableName,
	SchemaName,
	IndexName, 
	AvgFrag
	) SELECT ''?'' AS DBName
		,t.Name AS TableName
		,sc.Name AS SchemaName
		,i.name AS IndexName
		,s.avg_fragmentation_in_percent
	FROM ?.sys.dm_db_index_physical_stats(DB_ID(''?''), NULL, NULL, NULL, ''LIMITED'') AS s
		JOIN ?.sys.indexes i 
			ON s.Object_Id = i.Object_Id
			AND s.Index_Id = i.Index_Id
		JOIN ?.sys.tables t
			ON i.Object_Id = t.Object_Id
		JOIN ?.sys.schemas sc
			ON t.Schema_Id = sc.Schema_Id
	WHERE
		s.avg_fragmentation_in_percent > 15
		AND t.TYPE = ''U''
		AND s.page_count > 8
		AND s.index_id > 0;
	
	commit;'

DECLARE cList CURSOR
FOR select * from dba.dbo.IndexDefragHistory

OPEN cList
FETCH NEXT FROM cList
INTO @DBName, @TableName, @SchemaName, @IndexName, @AvgFrag

WHILE @@FETCH_STATUS = 0
BEGIN
	IF @AvgFrag BETWEEN 15.0 AND 30
	BEGIN 
		SET @Defrag = N'ALTER INDEX ' + @IndexName + ' ON ' + @DBName + '.' + @SchemaName + '.' + @TableName + ' REORGANIZE'
		--EXEC (@Defrag)
		PRINT (@Defrag)

		PRINT 'Reorganize index: ' + @DBName + '.' + @SchemaName + '.' + @TableName + '.' + @IndexName
	END
	ELSE IF @AvgFrag > 30
	BEGIN
		SET @Defrag = N'ALTER INDEX ' + @IndexName + ' ON ' + @DBName + '.' + @SchemaName + '.' + @TableName + ' REBUILD'
		--EXEC (@Defrag)
		PRINT (@Defrag)

		PRINT 'Rebuild index: ' + @DBName + '.' + @SchemaName + '.' + @TableName + '.' + @IndexName
	END

	FETCH NEXT FROM cList
	INTO @DbName, @TableName, @SchemaName, @IndexName, @AvgFrag 
END
CLOSE cList
DEALLOCATE cList

EXEC master.dbo.sp_IndexDefrag