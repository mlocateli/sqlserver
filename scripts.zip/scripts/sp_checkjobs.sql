USE [master]
GO

/****** Object:  StoredProcedure [dbo].[sp_checkjobs]    Script Date: 22/09/2015 10:41:43 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE sp_checkjobs (
       @order_by varchar(200) = 'job_name',
       @job_name varchar(200) = '%%',
       @last_outcome varchar(200) = '%%',
       @duration_min decimal(6,2) = 0.00,
       @last_run varchar(200) = '%%',
       @next_run varchar(200) = '%%',
       @enabled varchar(200) = '%%'
)
AS

BEGIN
CREATE TABLE #tempjob (job_name varchar(200), last_outcome varchar(200), duration_min decimal(6,2), last_run varchar(200), next_run varchar(200), enabled varchar(200));

/*** Seleciona o status da ultima execução dos jobs no servidor ***/
DECLARE @sql nvarchar(max);
DECLARE @sql2 nvarchar(max);

SET @sql = '
INSERT INTO #tempjob
SELECT a.name AS [Job Name], 
       CASE
              WHEN b.last_run_outcome = 1 THEN CONVERT(VARCHAR,''Succeeded'') 
              ELSE
              CASE
                     WHEN B.last_run_outcome = 3 THEN CONVERT(VARCHAR,''Cancelled'')
                     ELSE CONVERT(VARCHAR,''Failed'') 
              END 
       END AS [Last Outcome],
       CASE LEN(b.last_run_duration)
         WHEN 1 THEN cast(convert(decimal, b.last_run_duration) /60 AS decimal(6,2))
         WHEN 2 THEN cast(convert(decimal, b.last_run_duration) /60 AS decimal(6,2))
         WHEN 3 THEN cast(LEFT(b.last_run_duration, 1) + (convert(decimal,RIGHT(b.last_run_duration, 2)) /60) AS decimal(6,2))
         WHEN 4 THEN cast(LEFT(b.last_run_duration, 2) + (convert(decimal,RIGHT(b.last_run_duration, 2)) /60) AS decimal(6,2))
         WHEN 5 THEN cast((convert(decimal, (LEFT(b.last_run_duration, 1)) * 60) +SUBSTRING(CAST(b.last_run_duration AS nvarchar(5)), 2, 2) + (convert(decimal,RIGHT(b.last_run_duration, 2)) /60)) AS decimal(6,2))
         WHEN 6 THEN cast((convert(decimal, (LEFT(b.last_run_duration, 2)) * 60) +SUBSTRING(CAST(b.last_run_duration as nvarchar(6)), 3, 2) + (convert(decimal,RIGHT(b.last_run_duration, 2)) /60)) AS decimal(6,2))
         END AS [Duration (min)],
       CONVERT (varchar(200), MAX(msdb.dbo.AGENT_DATETIME(last_run_date, last_run_time)), 21) AS [Last run],
       ISNULL(CONVERT (varchar(200), MAX(c.next_scheduled_run_date), 21), ''Not Scheduled'') AS [Next Run],
          CASE WHEN MAX(a.enabled) = 1 THEN ''Enabled''
          ELSE ''Disabled''
          END AS [Enabled]
FROM msdb.dbo.sysjobs a, msdb.dbo.sysjobservers b, msdb.dbo.sysjobactivity c 
WHERE a.job_id = b.job_id AND b.job_id = c.job_id
       AND last_run_date <> 0
GROUP BY a.name, b.last_run_outcome, b.last_run_duration
ORDER BY a.name;'

EXEC (@sql);

SET @sql2 = '
SELECT * FROM #tempjob
WHERE 
       job_name LIKE ''' + @job_name + ''' AND
       last_outcome LIKE ''' + @last_outcome + ''' AND
       duration_min >= ''' + convert(nvarchar(max), @duration_min) + ''' AND
       last_run LIKE ''' + @last_run + ''' AND
       next_run LIKE ''' + @next_run + ''' AND
       enabled LIKE ''' + @enabled + '''
ORDER BY ' + @order_by;

EXEC (@sql2);

DROP TABLE #tempjob; 

/*** Fim ***/
END
GO
