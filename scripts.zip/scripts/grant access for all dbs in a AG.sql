
-- script bem útil, só informar o avg, e exportar o código para text e depois executar

SELECT 'USE [master]' + CHAR(10) + 'GO' + CHAR(10) + 'CREATE LOGIN [SICREDI\sabrina_menti] FROM WINDOWS WITH DEFAULT_DATABASE=[master]' + CHAR(10) + 
'GO' + CHAR(10) + 
'USE ' + name + CHAR(10)+
'GO' + CHAR(10) + 
'CREATE USER [SICREDI\sabrina_menti] FOR LOGIN [SICREDI\sabrina_menti]' + CHAR(10) + 
'GO' + CHAR(10) +
'USE ' + name + CHAR(10)+
'GO' + CHAR(10) +
'ALTER ROLE [db_datareader] ADD MEMBER [SICREDI\sabrina_menti]'  + CHAR(10) + 
'GO' + CHAR(10) +
'USE ' + name + CHAR(10)+
'GO' + CHAR(10)
FROM sys.databases 
where db_name(database_id) IN
(select distinct 
       rcs.database_name
from 
       master.sys.availability_groups ag 
       inner join master.sys.availability_group_listeners agl on ag.group_id = agl.group_id 
       inner join master.sys.availability_group_listener_ip_addresses lia on agl.listener_id = lia.listener_id 
       inner join master.sys.dm_hadr_database_replica_states drs on ag.group_id = drs.group_id 
       inner join master.sys.dm_hadr_database_replica_cluster_states rcs on drs.replica_id = rcs.replica_id 
       inner join master.sys.availability_replicas ar on drs.replica_id = ar.replica_id 
       inner join master.sys.dm_hadr_availability_replica_states ars on ar.replica_id = ars.replica_id
where ag.name = 'db0front1h'
)
