CREATE FUNCTION [dbo].[spb_fc_get_ult_st_oper] (
                                            @guid_operacao char(36),
                                            @st_operacao   int
                                           )
RETURNS int
AS
BEGIN
 
       DECLARE @st_operacao_atual  int,
             @qtd_msgs_env        int,
             @bool_msg_cnc        bit
 
       IF @st_operacao = 0 BEGIN
          RETURN @st_operacao
       END
 
       IF EXISTS(SELECT 1
                   FROM spb_tb_msg_ctrl_operacoes (NOLOCK)
                  WHERE guid_operacao  = @guid_operacao
                    AND cd_msg        IN (SELECT cd_msg
                                            FROM spb_tb_gen_msg_detalhe (NOLOCK)
                                           WHERE id_tipo_msg IN ('X', 'Y'))) BEGIN
          SET @bool_msg_cnc = 1
       END
       ELSE BEGIN
          SET @bool_msg_cnc = 0
       END
 
--     SELECT TOP 1
--            @st_operacao_atual = a.st_operacao
--       FROM spb_tb_pil_operacoes   a (NOLOCK),
--            spb_tb_gen_status_oper b (NOLOCK)
--      WHERE b.st_operacao    = a.st_operacao
--        AND b.flg_upd_piloto = 'S'
--        AND a.guid_operacao  = @guid_operacao
 
       SELECT @qtd_msgs_env = COUNT(*)
         FROM spb_tb_msg_ctrl_operacoes (NOLOCK)
       WHERE guid_operacao = @guid_operacao
          AND sentido       = 'E'
 
       IF @qtd_msgs_env > 1 BEGIN
          SELECT TOP 1
                 @st_operacao_atual = a.st_operacao
            FROM spb_tb_pil_operacoes   a (NOLOCK),
                 spb_tb_gen_status_oper b (NOLOCK)
           WHERE b.st_operacao    = a.st_operacao
             AND b.flg_upd_piloto = 'S'
             AND b.flg_tipo_R1    = 'S' -- 01/12/2010 Inserido por conta da msg SEL3400 que Cancela uma Opera��o j� confirmada!
             AND a.guid_operacao  = @guid_operacao
 
          IF @st_operacao_atual IS NULL BEGIN
             SELECT TOP 1
                    @st_operacao_atual = st_operacao_atual
               FROM spb_tb_pil_hist_protocolo_status (NOLOCK)
              WHERE guid_operacao = @guid_operacao
             ORDER BY dt_hr_geracao_protocolo DESC
          END
       END
 
       IF @st_operacao_atual IS NULL BEGIN
          SELECT TOP 1
                 @st_operacao_atual = a.st_operacao
            FROM spb_tb_pil_operacoes   a (NOLOCK),
                 spb_tb_gen_status_oper b (NOLOCK)
           WHERE b.st_operacao    = a.st_operacao
             AND b.flg_upd_piloto = 'S'
             AND a.guid_operacao  = @guid_operacao
             AND a.st_operacao    > 10
       END
 
       IF @st_operacao_atual IS NULL BEGIN
          SELECT TOP 1
                 @st_operacao_atual = a.st_operacao_atual
            FROM spb_tb_pil_hist_protocolo_status a (NOLOCK),
                 spb_tb_gen_status_oper           b (NOLOCK)
           WHERE b.st_operacao        = a.st_operacao_atual
             AND b.flg_repres_status IN ('C', 'R')
             AND a.guid_operacao      = @guid_operacao
          ORDER BY a.dt_hr_geracao_protocolo DESC
       END
 
       IF @st_operacao_atual IS NULL AND
          @bool_msg_cnc = 0 BEGIN
          SELECT TOP 1
                 @st_operacao_atual = a.st_operacao_atual
            FROM spb_tb_pil_hist_protocolo_status a (NOLOCK),
                 spb_tb_gen_status_oper           b (NOLOCK)
           WHERE b.st_operacao   = a.st_operacao_atual
             AND b.flg_tipo_R1   = 'S'
             AND a.guid_operacao = @guid_operacao
          ORDER BY a.dt_hr_geracao_protocolo DESC
       END
 
       IF @st_operacao_atual IS NULL BEGIN
          SELECT TOP 1
                 @st_operacao_atual = a.st_operacao_atual
            FROM spb_tb_pil_hist_protocolo_status a (NOLOCK),
                 spb_tb_gen_status_oper           b (NOLOCK)
           WHERE b.st_operacao       = a.st_operacao_atual
             AND b.flg_repres_status = 'I'
             AND a.guid_operacao     = @guid_operacao
          ORDER BY a.dt_hr_geracao_protocolo DESC
       END
 
       IF @st_operacao_atual IS NULL BEGIN
          IF EXISTS(SELECT 1 
                      FROM spb_tb_gen_status_oper (NOLOCK)
                     WHERE st_operacao = @st_operacao
                       AND (flg_repres_status     IN ('C', 'R')
                        OR  flg_permite_alteracao  = 'S')) BEGIN
             SET @st_operacao_atual = @st_operacao
          END
       END
 
       IF @st_operacao_atual IS NULL BEGIN
          SELECT TOP 1
                 @st_operacao_atual = a.st_operacao_atual
            FROM spb_tb_pil_hist_protocolo_status a (NOLOCK),
                 spb_tb_gen_status_oper           b (NOLOCK)
           WHERE b.st_operacao   = a.st_operacao_atual
             AND a.guid_operacao = @guid_operacao
          ORDER BY a.dt_hr_geracao_protocolo DESC
       END
 
       IF @st_operacao_atual IS NULL BEGIN
          SET @st_operacao_atual = @st_operacao
       END
 
       RETURN @st_operacao_atual
 
END
