

CREATE OR ALTER PROCEDURE [dbo].[ReenviaR2] @nr_ctrl_if char(20)    
as    
    
BEGIN TRANSACTION    
    
    update dbo.spb_tb_leg_protocolos    
    set dt_hr_envio   = NULL,    
    flg_enviar    = 'S',    
    flg_proc_util = 'N',    
    dt_hr_lock    = '19000101',    
    guid_lock     = '{00000000-0000-0000-0000-000000000000}'    
    where guid_operacao in (select guid_operacao    
                           from spb_tb_pil_operacoes (nolock)    
                          where nr_ctrl_if = @nr_ctrl_if)    
           
IF @@ERROR <> 0    
    BEGIN    
        ROLLBACK TRANSACTION    
        PRINT N'There was a problem...' --etc    
    END    
    ELSE    
     
COMMIT TRANSACTION    

-- exec reenviar2 'STR20200617033137384'

