/*
TESTE CONECTIVIDADE CIP - EVOLUTION CQL
*/

-- Tabelas envolvidas nesse monitoramento
cql_ope_consultas e cql_ope_respostas, 

-- Valida��o de comunica��o com a CIP
DECLARE @retorno varchar(8000)
EXECUTE dbo.cql_sp_teste_conectividade 2, 1, @retorno OUTPUT
PRINT @retorno
