/*
Necessito de um relat�rio mais geral do que anterior. Assim, pe�o um relat�rio cujo usu�rios ednei_rodrigues, 
paulo_pfilho e tiago_comasseto tenham sido envolvidos (incidentes e requisi��es). Se poss�vel, verificar a 
possibilidade de termos algumas colunas onde possamos filtrar quem foi o grupo solucionador, 
Tempo de atividade Total, tempo gasto (naquela coluna logs), Tipo de Requisi��o e reportado por.
*/

use mdb
go

select top 10 *
from mdb.dbo.z_ciclo_vida

select top 10 zincidente, *
from mdb.dbo.call_req

select top 1 *
from mdb.dbo.ca_contact

select top 1 *
from mdb.dbo.z_ciclo_vida


use mdb
go

select top 1 *
from mdb.dbo.z_ciclo_vida

select top 1 *
from mdb.dbo.call_req
where zincidente is not null

select top 1 *
from mdb.dbo.ca_contact

SELECT c.last_name as [equipe], ref_num, cr.type AS [tipo_requisicao],
			dateadd(ss,open_date,'1969-12-31 21:00:00') AS [open_date],
			dateadd(ss,resolve_date,'1969-12-31 21:00:00') AS [resolve_date],
			dateadd(ss,close_date,'1969-12-31 21:00:00') AS [close_date],
			dateadd(ss,z_dat_Inicio,'1969-12-31 21:00:00') AS [ini_atendimento],
			dateadd(ss,z_dat_Fim,'1969-12-31 21:00:00') AS [fim_atendimento],
			summary,
			(select last_name from ca_contact where contact_uuid = cr.customer) AS [Solicitante] --, description *
FROM mdb.dbo.z_ciclo_vida cv WITH (NOLOCK)
	INNER JOIN mdb.dbo.ca_contact c WITH (NOLOCK) ON cv.last_mod_by = c.contact_uuid
	INNER JOIN mdb.dbo.call_req cr WITH (NOLOCK) ON cv.z_srl_CallReq = cr.persid
WHERE dateadd(ss,open_date,'1969-12-31 21:00:00') >= '2014-10-01'
	AND c.last_name IN ('EDNEI FELIPE FALEIRO RODRIGUES', 'PAULO RICARDO SOUZA POFFAL FILHO', 'TIAGO KOLLING COMASSETO')
GROUP BY c.last_name, ref_num, cr.type,
			dateadd(ss,cr.open_date,'1969-12-31 21:00:00'),
			dateadd(ss,cr.resolve_date,'1969-12-31 21:00:00'),
			dateadd(ss,cr.close_date,'1969-12-31 21:00:00'),
			dateadd(ss,z_dat_Inicio,'1969-12-31 21:00:00'),
			dateadd(ss,z_dat_Fim,'1969-12-31 21:00:00'),
			summary, cr.customer
ORDER BY cr.ref_num, dateadd(ss,cr.open_date,'1969-12-31 21:00:00')





