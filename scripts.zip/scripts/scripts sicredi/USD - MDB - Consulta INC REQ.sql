
USE mdb
GO

SELECT ca_contact.last_name as [equipe], ref_num, type,
			dateadd(ss,open_date,'1969-12-31 21:00:00') AS [open_date],
			dateadd(ss,resolve_date,'1969-12-31 21:00:00') AS [resolve_date],
			dateadd(ss,close_date,'1969-12-31 21:00:00') AS [close_date], 
			summary--, description
FROM mdb.dbo.call_req WITH (NOLOCK)
	INNER JOIN mdb.dbo.ca_contact  WITH (NOLOCK) on call_req.group_id = ca_contact.contact_uuid
WHERE dateadd(ss,open_date,'1969-12-31 21:00:00') >= '2014-10-01'
	AND ca_contact.last_name IN ('Aplica��es Seguran�a', 'APLICACOES SEGURANCA NAO PRODUCAO')
	--AND DESCRIPTION LIKE '%LDAP%'
				
				
--SELECT last_name
--FROM mdb.dbo.ca_contact
--WHERE contact_type = 2308 and inactive = 0
--AND last_name IN ('Aplica��es Seguran�a', 'APLICACOES SEGURANCA NAO PRODUCAO')
--ORDER BY last_name


