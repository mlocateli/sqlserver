
  -- ===========================================================
  -- Default Constraints
  -- How to script out Default Constraints in SQL Server 2005
  -- ===========================================================
  
  -- view results in text, to make copying and pasting easier
  -- drop default constraints
  SELECT
      'ALTER TABLE ' +
      QuoteName(OBJECT_NAME(sc.id)) +
      CHAR(10) +
      ' DROP CONSTRAINT ' +
      QuoteName(OBJECT_NAME(sc.cdefault))
  FROM
      syscolumns sc
      INNER JOIN
      sysobjects as so on sc.cdefault = so.id
      INNER JOIN
      syscomments as sm on sc.cdefault = sm.id
  WHERE
      OBJECTPROPERTY(so.id, N'IsDefaultCnst') = 1
  
  -- create default constraints
  SELECT
      'ALTER TABLE ' +
      QuoteName(OBJECT_NAME(sc.id)) +
      'WITH NOCHECK ADD CONSTRAINT ' +
      QuoteName(OBJECT_NAME(sc.cdefault))+
      ' DEFAULT ' +
      sm.text +
      ' FOR ' + QuoteName(sc.name)
      + CHAR(13)+CHAR(10)
  FROM
      syscolumns sc
      INNER JOIN
      sysobjects as so on sc.cdefault = so.id
      INNER JOIN
      syscomments as sm on sc.cdefault = sm.id
  WHERE
      OBJECTPROPERTY(so.id, N'IsDefaultCnst') = 1
