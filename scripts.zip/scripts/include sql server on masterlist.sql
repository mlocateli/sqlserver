
USE DBMON000

/*
This script is to include the new servers on Daily Check List tasks
This script will include the host on MasterListGNA and Servers_GNA tables
Autor: Marcos Locateli Gontarski 
Date: 01/23/2012
*/

DECLARE @DeviceName varchar(50)
DECLARE @InstanceName varchar(50)
DECLARE @FullRemote varchar(50)
DECLARE @ServerFunction varchar(50)
DECLARE @Address varchar(50)
DECLARE @OSName varchar(50)
DECLARE @GAOrganization varchar(50)
DECLARE @iSec varchar(50)
DECLARE @TWS varchar(50)

DECLARE @SQLCommand1 varchar(350)

SET @DeviceName = 'SQLRALP02'
SET @InstanceName = 'SQLRALP02.ga.local\ASA_SQLSERVER'
SET @FullRemote = '1'
SET @ServerFunction = 'GLN SQL Server'
SET @Address = '172.27.104.7'
SET @OSName = 'Windows Server 2008 Standard'
SET @GAOrganization = 'DS - Raleigh Reinforcing Steel'
SET @iSec = 'Compliant'
SET @TWS = ''

SET @SQLCommand1 = 'INSERT INTO MasterListGNA (DeviceName, InstanceName, FullRemote, ServerFunction, Address, OSName, GAOrganization, iSec, TWS) 
	VALUES (''' +@DeviceName+ ''', '''+@InstanceName+''', '''+@FullRemote+''', '''+@ServerFunction+''', '''+@Address+''', '''+@OSName+''', '''+@GAOrganization+''', '''+@iSec+''', '''+@TWS+''')'

PRINT @SQLCOmmand1
--EXEC (@SQLCommand1)

--SELECT * FROM MasterListGNA ORDER BY InstanceName

DECLARE @Servidor varchar(50)
DECLARE @StringConexao varchar(250)
DECLARE @Ambiente varchar(50)
DECLARE @Status varchar(50)
DECLARE @VersaoSQL varchar(50)
DECLARE @Usuario varchar(50)
DECLARE @Senha varchar(50)
DECLARE @Cluster varchar(50)

DECLARE @SQLCommand2 varchar(350)

SET @Servidor = 'SQLRALP02.ga.local\ASA_SQLSERVER'
SET @StringConexao = 'Provider=SQLOLEDB.1;Data Source='+@Servidor+';User ID=sa_ibm;password=hebfUZa0Hg6zJX;'
SET @Ambiente = 'Production'
SET @Status = 0
SET @VersaoSQL = '2008'
SET @Usuario = 'sa_ibm'
SET @Senha = 'hebfUZa0Hg6zJX'
SET @Cluster = '-'

SET @SQLCommand2 = 'INSERT INTO Servers_GNA (Servidor, StringConexao, Ambiente, Status, VersaoSQL, Usuario, Senha, Cluster) 
	VALUES (''' +@Servidor+ ''', '''+@StringConexao+''', '''+@Ambiente+''', '''+@Status+''', '''+@VersaoSQL+''', '''+@Usuario+''', '''+@Senha+''', '''+@Cluster+''')'

PRINT @SQLCOmmand2
--EXEC (@SQLCommand2)

--SELECT * FROM Servers_GNA ORDER BY Servidor



