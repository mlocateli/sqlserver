CREATE PROCEDURE sp_auditRoles (@db varchar(200) = NULL)
AS

/*** Verifica o collation para evitar erros no join entre database_principals e server_principals ***/
DECLARE @Collation as SYSNAME
SET @Collation = cast(DATABASEPROPERTYEX('Tempdb', 'Collation') as nvarchar)

/*** Seleciona os usuários e as roles que foram dadas a eles no banco ***/
DECLARE @sql nvarchar(max)
SET @sql = 'use '+ISNULL(@db, db_name(db_id()))+' 

SELECT 
       DISTINCT 
       CASE sp.is_disabled    
       WHEN 0 THEN ''Enabled''
       ELSE ''Disabled''
       END AS status,
       mp.type_desc as db_user_type,
       mp.name AS db_user, 
       rp.name AS db_role_member
FROM sys.database_role_members rm
       join sys.database_principals mp on (rm.member_principal_id = mp.principal_id)
       join sys.database_principals rp on (rm.role_principal_id = rp.principal_id)
       join sys.server_principals sp on (mp.name COLLATE '+ @Collation +' = sp.name)
WHERE mp.name not in (''dbo'', ''public'') 
       and mp.type not in (''A'', ''R'', ''C'', ''K'')
       /** A=App role, R=Database role, C=User mapped to a certificate, K = User mapped to an asymmetric key **/
ORDER BY status, db_user_type, db_user'

EXEC(@sql)

/*** Fim ***/
GO
