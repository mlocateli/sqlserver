
/*
restore recovery a database without LDF file.
recreate LDF file
restore from MDF file
recovery from MDF file
*/

CREATE DATABASE AdventureWorksDW2012 ON
(FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\DATA\AdventureWorksDW2012_Data.mdf')
FOR ATTACH_REBUILD_LOG

