    
CREATE OR ALTER PROCEDURE [dbo].[sp_RestoreHomolog] (    
 @DirectoryPath varchar(255),    
 @OriginalDBName varchar(128),    
 @DBtobeRestored varchar(128)    
)    
AS    
    
    
  SET NOCOUNT ON    
    
  DECLARE @CommandDir AS varchar(1000)    
    
  DECLARE @DirectoryFiles AS TABLE (    
    [id] int IDENTITY (1, 1),    
    [filename] varchar(255),    
    [depth] int,    
    [file] int    
  )    
    
  INSERT INTO @DirectoryFiles    
  EXECUTE master.dbo.xp_dirtree @DirectoryPath,    
                                1,    
                                1    
    
  DELETE FROM @DirectoryFiles    
  WHERE [file] <> 1    
    
  DECLARE @MaxID int    
  DECLARE @CurrentID int = 1    
  DECLARE @FirstLSN numeric(25, 0)    
  DECLARE @LastLSN numeric(25, 0)    
  --DECLARE @CheckpointLSN  NUMERIC(25,0)    
  --DECLARE @DatabaseBackupLSN NUMERIC(25,0)    
  DECLARE @Position int    
  DECLARE @FileName varchar(255)    
  DECLARE @Command varchar(500) = 'RESTORE HEADERONLY FROM DISK='    
    
  DECLARE @HeaderInfo AS TABLE (    
    [ID] int IDENTITY (1, 1),    
    [FileName] varchar(255),    
    [BackupName] varchar(128),    
    [BackupDescription] varchar(255),    
    [BackupType] smallint,    
    [ExpirationDate] datetime,    
    [Compressed] bit,    
    [Position] smallint,    
    [DeviceType] tinyint,    
    [UserName] varchar(128),    
    [ServerName] varchar(128),    
    [DatabaseName] varchar(128),    
    [DatabaseVersion] int,    
    [DatabaseCreationDate] datetime,    
    [BackupSize] numeric(20, 0),    
    [FirstLSN] numeric(25, 0),    
    [LastLSN] numeric(25, 0),    
    [CheckpointLSN] numeric(25, 0),    
    [DatabaseBackupLSN] numeric(25, 0),    
    [BackupStartDate] datetime,    
    [BackupFinishDate] datetime,    
    [SortOrder] smallint,    
    [CodePage] smallint,    
    [UnicodeLocaleId] int,    
    [UnicodeComparisonStyle] int,    
    [CompatibilityLevel] tinyint,    
    [SoftwareVendorId] int,    
    [SoftwareVersionMajor] int,    
    [SoftwareVersionMinor] int,    
    [SoftwareVersionBuild] int,    
    [MachineName] varchar(128),    
    [Flags] int,    
    [BindingID] uniqueidentifier,    
    [RecoveryForkID] uniqueidentifier,    
    [Collation] varchar(128),    
    [FamilyGUID] uniqueidentifier,    
    [HasBulkLoggedData] bit,    
    [IsSnapshot] bit,    
    [IsReadOnly] bit,    
    [IsSingleUser] bit,    
    [HasBackupChecksums] bit,    
    [IsDamaged] bit,    
    [BeginsLogChain] bit,    
    [HasIncompleteMetaData] bit,    
    [IsForceOffline] bit,    
    [IsCopyOnly] bit,    
    [FirstRecoveryForkID] uniqueidentifier,    
    [ForkPointLSN] bigint,    
    [RecoveryModel] varchar(30),    
    [DifferentialBaseLSN] numeric(25, 0),    
    [DifferentialBaseGUID] uniqueidentifier,    
    [BackupTypeDescription] varchar(60),    
    [BackupSetGUID] uniqueidentifier,    
    [CompressedBackupSize] bigint,    
    [Containment] int,    
 [KeyAlgorithm] VARCHAR(200),    
 [EncryptorThumbprint] VARCHAR(200),    
 [EncryptorType] VARCHAR(200)    
  )    
    
  SELECT @MaxID = MAX(id) FROM @DirectoryFiles    
    
  BEGIN TRY    
    WHILE @CurrentID <= @MaxID    
    BEGIN    
   SELECT    
        @FileName = [filename]    
      FROM @DirectoryFiles    
      WHERE id = @CurrentID    
          
   PRINT @Command + '''' + @DirectoryPath + @FileName + ''''    
    
   INSERT INTO @HeaderInfo (BackupName, BackupDescription, BackupType, ExpirationDate, Compressed, Position, DeviceType, UserName, ServerName, DatabaseName,     
          DatabaseVersion,DatabaseCreationDate, BackupSize, FirstLSN, LastLSN, CheckpointLSN, DatabaseBackupLSN, BackupStartDate, BackupFinishDate, SortOrder,     
          [CodePage],UnicodeLocaleId, UnicodeComparisonStyle, CompatibilityLevel, SoftwareVendorId, SoftwareVersionMajor, SoftwareVersionMinor, SoftwareVersionBuild,MachineName, Flags,     
          BindingID, RecoveryForkID, Collation, FamilyGUID, HasBulkLoggedData, IsSnapshot, IsReadOnly, IsSingleUser, HasBackupChecksums,IsDamaged,     
          BeginsLogChain, HasIncompleteMetaData, IsForceOffline, IsCopyOnly, FirstRecoveryForkID, ForkPointLSN, RecoveryModel, DifferentialBaseLSN,DifferentialBaseGUID, BackupTypeDescription,     
          BackupSetGUID, CompressedBackupSize, Containment, KeyAlgorithm, EncryptorThumbprint, EncryptorType)    
   EXEC (@Command + '''' + @DirectoryPath + @FileName + '''')    
       
          
   UPDATE @HeaderInfo    
  SET [FileName] = @FileName    
      WHERE [FileName] IS NULL    
          
   SET @CurrentID = @CurrentID + 1    
    END    
        
 SELECT * FROM @HeaderInfo;    
    
    DELETE FROM @HeaderInfo    
    WHERE [FileName] IS NULL    
  END TRY    
    
  -- Check if exists other files    
  BEGIN CATCH    
    RAISERROR ('Diretório possui arquivos que não são backups.', 16, 1)    
  END CATCH    
    
  DECLARE @RestoreCommandFULL varchar(1000)    
  DECLARE @RestoreCommandDIFF varchar(1000)    
  DECLARE @RestoreCommandLOG varchar(8000)    
  SET @RestoreCommandFULL = CHAR(10) + 'RESTORE DATABASE [' + @DBtobeRestored + ']' + CHAR(10) + 'FROM '    
  SET @RestoreCommandDIFF = ''    
  SET @RestoreCommandLOG = ''    
      
  IF EXISTS (SELECT * FROM @HeaderInfo WHERE BackupType = 1 AND DatabaseName = @OriginalDBName)    
  BEGIN    
    -- Begin Restore FULL */    
 DECLARE @backupfiles int = (SELECT COUNT(*) FROM @HeaderInfo WHERE BackupType = 1 AND DatabaseName = @OriginalDBName);    
    DECLARE @currentfile int = 1;    
    WHILE @currentfile <= @backupfiles    
    BEGIN    
      SELECT TOP 1    
        @FileName = FileName,    
        @FirstLSN = FirstLSN,    
        @LastLSN = LastLSN    
      FROM     
  @HeaderInfo    
      WHERE     
  BackupType = 1    
  AND DatabaseName = @OriginalDBName    
      ORDER BY     
  LastLSN DESC,    
  ID ASC;    
    
      DELETE FROM @HeaderInfo WHERE [FileName] = @FileName;    
    
      SET @RestoreCommandFULL = @RestoreCommandFULL + CHAR(10) + 'DISK=N''' + @DirectoryPath + @FileName + ''''    
          
   IF @currentfile < @backupfiles    
      BEGIN    
        SET @RestoreCommandFULL = @RestoreCommandFULL + ','    
      END    
    
      SET @currentfile = @currentfile + 1;    
    END    
    
    SET @RestoreCommandFULL = @RestoreCommandFULL + CHAR(10) + 'WITH REPLACE, NORECOVERY, STATS=1;' + CHAR(10)    
    PRINT @RestoreCommandFULL    
    -- End Restore FULL */    
    
    -- Begin Restore DIFF */    
    IF EXISTS (SELECT    
        *    
      FROM @HeaderInfo    
      WHERE BackupType = 5    
      AND DatabaseName = @OriginalDBName    
      AND FirstLSN >= @LastLSN)    
    BEGIN    
      SELECT TOP 1    
        @FileName = FileName,    
        @FirstLSN = FirstLSN,    
        @LastLSN = LastLSN    
      FROM @HeaderInfo    
      WHERE BackupType = 5    
      AND FirstLSN >= @LastLSN    
      AND DatabaseName = @OriginalDBName    
      ORDER BY LastLSN DESC    
    
      SET @RestoreCommandDIFF = CHAR(10) + 'RESTORE DATABASE [' + @DBtobeRestored + ']' + CHAR(10) + 'FROM DISK=N''' + @DirectoryPath + @FileName + '''' + CHAR(10) + 'WITH NORECOVERY, STATS=1;' + CHAR(10)    
      PRINT @RestoreCommandDIFF    
    END    
    ELSE    
    BEGIN    
      PRINT CHAR(10)    
      PRINT '/********************************************************************************'    
      PRINT '########### Não foi encontrado backup diferencial para este restore. ############'    
      PRINT '********************************************************************************/'    
      PRINT CHAR(10)    
    END    
    -- End Restore DIFF */    
    
    -- Begin Restore LOG */    
    DECLARE @Count int    
    DECLARE @CountUsed int    
    SELECT  @Count = COUNT(*) FROM @HeaderInfo WHERE BackupType = 2 AND DatabaseName = @OriginalDBName;    
    SELECT  @CountUsed = COUNT(*) FROM @HeaderInfo     
 WHERE     
   BackupType = 2     
   AND DatabaseName = @OriginalDBName    
   AND (FirstLSN >= @LastLSN OR LastLSN >= @LastLSN)    
        
 -- SELECT * FROM @HeaderInfo    
    
    IF @CountUsed > 0    
    BEGIN    
      PRINT CHAR(10)    
      PRINT '--------------------------------------------------------------------------------'    
      PRINT '-- Encontrado ' + CAST(@Count AS varchar(6)) + ' arquivo(s) de backup de log'    
      PRINT '-- Serão utilizados ' + +CAST(@CountUsed AS varchar(6)) + ' arquivo(s) de backup de log'    
      PRINT '-- Serão ignorados ' + +CAST(@Count - @CountUsed AS varchar(6)) + ' arquivo(s) de backup de log'    
      PRINT '--------------------------------------------------------------------------------'    
PRINT CHAR(10)    
      DECLARE @X int = 1    
      WHILE @X <= @CountUsed    
      BEGIN    
        SELECT TOP 1    
          @FileName = FileName,    
          @FirstLSN = FirstLSN,    
          @LastLSN = LastLSN    
        FROM @HeaderInfo    
        WHERE BackupType = 2    
    AND DatabaseName = @OriginalDBName    
    AND (FirstLSN >= @LastLSN OR LastLSN >= @LastLSN)    
        ORDER BY FirstLSN;    
    
        SET @RestoreCommandLOG = @RestoreCommandLOG + CHAR(10) + 'RESTORE LOG [' + @DBtobeRestored + ']' + CHAR(10) + 'FROM DISK=N''' + @DirectoryPath + ISNULL(@FileName, 'NULO') + '''' + CHAR(10) + 'WITH NORECOVERY, STATS=1;' + CHAR(10)    
    
  DELETE FROM @HeaderInfo    
  WHERE BackupType = 2    
   AND DatabaseName = @OriginalDBName    
   AND FileName = @FileName;    
    
        SET @X = @X + 1    
      END    
    END    
    ELSE    
    BEGIN    
      PRINT '/********************************************************************************'    
      PRINT '############## Não foi encontrado backup de log para este restore. ##############'    
      PRINT '********************************************************************************/'    
    END    
    -- End Restore LOG */    
    
    -- Command to open database    
    DECLARE @RestoreCommandEnd varchar(1000);    
    SET @RestoreCommandEnd = CHAR(10) + 'RESTORE DATABASE [' + @DBtobeRestored + '];' + CHAR(10);    
    PRINT @RestoreCommandEnd;    
    PRINT '/********************************************************************************'    
    PRINT '############## FIMMM. ##############'    
    PRINT '/********************************************************************************'    
    DECLARE @end varchar(8000);    
    SET @end = @RestoreCommandFULL;    
 SET @end = @end + @RestoreCommandDIFF;    
 SET @end = @end + @RestoreCommandLOG;    
 SET @end = @end + @RestoreCommandEnd;    
    PRINT (@end);    
 PRINT ('DATA DE INÍCIO DO RESTORE: ' + CONVERT(NVARCHAR(30), GETDATE(), 120));    
    EXEC (@end);    
 PRINT ('DATA DE TÉRMINO DO RESTORE: ' + CONVERT(NVARCHAR(30), GETDATE(), 120));    
  END    
  ELSE    
  BEGIN    
    RAISERROR ('Não foi encontrado backup full para este restore..', 16, 1);    
  END    
    