
-- rotina para gerar valores rand�micos
CREATE VIEW vRandom
AS
SELECT randval = CRYPT_GEN_RANDOM (8)
GO

-- gera caracteres rand�micos
CREATE FUNCTION [dbo].[GenPass]()
RETURNS VARCHAR(8)
AS
BEGIN
   -- Declare the variables here
   DECLARE @Result VARCHAR(8)
   DECLARE @BinaryData VARBINARY(8)
   DECLARE @CharacterData VARCHAR(8)
 
   SELECT @BinaryData = randval
   FROM vRandom
 
   Set @CharacterData=cast ('' as xml).value ('xs:base64Binary(sql:variable("@BinaryData"))',
                   'varchar (max)')
   
   SET @Result = @CharacterData
   
   -- Return the result of the function
   RETURN @Result
END
GO

DECLARE @newPass VARCHAR(8)
SELECT @newPass = dbo.GenPass()
PRINT @newPass 


-- gera n�meros rand�micos
Declare @RandomPhoneNumber int

Declare @LowerLimitForPhoneNumber int
Declare @UpperLimitForPhoneNumber int

--define o intervalo de valores para os n�meros que ser�o gerados
Set @LowerLimitForPhoneNumber = 11111111
Set @UpperLimitForPhoneNumber = 999999999

Declare @count int
Set @count = 1

-- loop para gerar 10 n�mero rand�micos
While @count <= 10
Begin 

   Select @RandomPhoneNumber = Round(((@UpperLimitForPhoneNumber - @LowerLimitForPhoneNumber) * Rand()) + @LowerLimitForPhoneNumber, 0)
   -- select  @RandomPhoneNumber

   Print @count
   Set @count = @count + 1
End


-- create a table to receive the random values
create table emp (eid int identity(1,1) primary key, Firstname varchar(50),Lastname varchar(50), Phonenumber int)

create nonclustered index nciLastName on emp(Lastname)

-- loop to insert random values into a table

-- gera n�meros rand�micos
Declare @RandomPhoneNumber int

Declare @LowerLimitForPhoneNumber int
Declare @UpperLimitForPhoneNumber int

--define o intervalo de valores para os n�meros que ser�o gerados
Set @LowerLimitForPhoneNumber = 11111111
Set @UpperLimitForPhoneNumber = 999999999

DECLARE @FirstName VARCHAR(8)
DECLARE @LastName VARCHAR(8)

-- SELECT @FirstName = dbo.GenPass(), @LastName = dbo.GenPass()
-- PRINT @FirstName +' '+ @LastName

Declare @Id int
Set @Id = 1

While @Id <= 8000
Begin 
	SELECT @FirstName = dbo.GenPass(), @LastName = dbo.GenPass()

	select @RandomPhoneNumber = Round(((@UpperLimitForPhoneNumber - @LowerLimitForPhoneNumber) * Rand()) + @LowerLimitForPhoneNumber, 0)
	-- select @RandonPhoneNumber

	Insert Into emp values (@FirstName, @LastName, @RandomPhoneNumber)

	Print @Id
	Set @Id = @Id + 1
End

-- selecting the random values
select *
from emp
where Lastname = 'zd0JEEz+'
--where PhoneNumber = 699748052


