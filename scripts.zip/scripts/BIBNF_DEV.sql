USE [master]
GO

/****** Object:  LinkedServer [BIBNF_DEV]    Script Date: 04/03/2020 11:57:04 ******/
EXEC master.dbo.sp_addlinkedserver @server = N'BIBNF_DEV', @srvproduct=N'Oracle', @provider=N'OraOLEDB.Oracle', @datasrc=N'coredbhom'
 /* For security reasons the linked server remote logins password is changed with ######## */
EXEC master.dbo.sp_addlinkedsrvlogin @rmtsrvname=N'BIBNF_DEV',@useself=N'False',@locallogin=NULL,@rmtuser=N'dda_integrador_owner',@rmtpassword='dd828sa'
GO

EXEC master.dbo.sp_serveroption @server=N'BIBNF_DEV', @optname=N'collation compatible', @optvalue=N'false'
GO

EXEC master.dbo.sp_serveroption @server=N'BIBNF_DEV', @optname=N'data access', @optvalue=N'true'
GO

EXEC master.dbo.sp_serveroption @server=N'BIBNF_DEV', @optname=N'dist', @optvalue=N'false'
GO

EXEC master.dbo.sp_serveroption @server=N'BIBNF_DEV', @optname=N'pub', @optvalue=N'false'
GO

EXEC master.dbo.sp_serveroption @server=N'BIBNF_DEV', @optname=N'rpc', @optvalue=N'false'
GO

EXEC master.dbo.sp_serveroption @server=N'BIBNF_DEV', @optname=N'rpc out', @optvalue=N'false'
GO

EXEC master.dbo.sp_serveroption @server=N'BIBNF_DEV', @optname=N'sub', @optvalue=N'false'
GO

EXEC master.dbo.sp_serveroption @server=N'BIBNF_DEV', @optname=N'connect timeout', @optvalue=N'0'
GO

EXEC master.dbo.sp_serveroption @server=N'BIBNF_DEV', @optname=N'collation name', @optvalue=null
GO

EXEC master.dbo.sp_serveroption @server=N'BIBNF_DEV', @optname=N'lazy schema validation', @optvalue=N'false'
GO

EXEC master.dbo.sp_serveroption @server=N'BIBNF_DEV', @optname=N'query timeout', @optvalue=N'0'
GO

EXEC master.dbo.sp_serveroption @server=N'BIBNF_DEV', @optname=N'use remote collation', @optvalue=N'true'
GO

EXEC master.dbo.sp_serveroption @server=N'BIBNF_DEV', @optname=N'remote proc transaction promotion', @optvalue=N'true'
GO

