SQL 2005 / 2008
---------------

select 'grant execute on [' + r.ROUTINE_NAME + '] to ' + u.name + char(13) + char(10) + 'go' +  char(13) + char(10)
from INFORMATION_SCHEMA.ROUTINES as r, sysusers u
where u.islogin >0 and hasdbaccess =1 and u.name <> 'dbo'   -- AJUSTAR USER
order by u.name


SQL 2000
--------

select [Lista de SPs] = 'grant exec on ' + convert(varchar(134), o.name) + ' to [' + u.name + ']
go'
from sysobjects o, 
syscomments c, sysusers u
	where c.colid = 1
		and o.type in ('P', 'FN', 'TF', 'IF')/* Object type of Procedure, scalar UDF, table UDF */
		and c.id = o.id
		and permissions (o.id)&32 <> 0 and u.status >0 and u.name <> 'dbo'   -- AJUSTAR USER
	order by 1



Identity Insert:
----------------

grant alter on <table> to <user>

revoke alter on <table> to <user>




2005 e 2008 - View definition
-----------------------------

use dbmap000

go

GRANT VIEW Definition TO SMAP0




DENY VIEW DEFINITION TO SINT1
go




Visualizar plano de execu��o:
-----------------------------

GRANT SHOWPLAN TO AdventureWorksUser


