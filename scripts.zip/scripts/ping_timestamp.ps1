
-- powershell script to colect ping + timestamp

PS> ping.exe app3cmparqs001p -t | ForEach {"{0} - {1}" -f (Get-Date),$_} > C:\temp\ping_witness.txt
