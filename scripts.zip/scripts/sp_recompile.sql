USE [master]
GO
/****** Object:  StoredProcedure [sys].[sp_recompile]    Script Date: 07/10/2015 16:45:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER procedure [sys].[sp_recompile]
    @objname	 	nvarchar(776)
as
    -- do sets and declares
    Set nocount on
    declare @objid      int

	BEGIN TRANSACTION
    -- CHECK VALIDITY OF OBJECT NAME --
    --  (1) Must exist in current database
    --  (2) Must be a table or an executable object
    --  (3) Must not be a Hekaton procedure.
    select @objid = object_id(@objname, 'local')

        if @objid is null OR
            (ObjectProperty(@objid, 'IsTable') = 0 AND ObjectProperty(@objid, 'IsExecuted') = 0)
        begin
	        COMMIT TRANSACTION
	        raiserror(15165,-1,-1 ,@objname)
	        return @@error
        end

	if not (@objid is null)
	begin
		if (ObjectProperty(@objid, 'IsExecuted') <> 0 AND
			ObjectProperty(@objid, 'IsInlineFunction') = 0 AND
			ObjectProperty(@objid, 'IsView') = 0 AND
			-- Hekaton procedure cannot be recompiled
			-- Make them go through schema version bumping branch, which will fail
	    		ObjectProperty(@objid, 'ExecIsCompiledProc') = 0)
		begin
			-- The object has its own cache entry.  Removing it from cache will result in recompile on next execution.
			-- Recompiling plans referencing the object is not needed according to sp_recompile semantics in BOL,
			-- nor would it achieve anything useful.

			-- Check ALTER permission on the object.
			if has_perms_by_name(@objname, 'object', 'alter') = 0
			begin
				declare @db_name sysname = db_name(), @object_name sysname = object_name(@objid), @schema_name sysname = object_schema_name(@objid);
				declare @db_len int = datalength(@db_name), @schema_len int = datalength(@schema_name), @object_len int = datalength(@object_name);
				raiserror(229, -1, -1, N'ALTER', @object_len, @object_name, @db_len, @db_name, @schema_len, @schema_name);
				return @@error;
			end

			-- Remove the object from plan cache.
			declare @db_id int = db_id();
			EXEC sp_recompile_module @db_id, @objid
		end
		else
		begin
			-- For table/view/inline-function, all plans referencing the object need to be recompiled according to
			-- sp_recompile semantics in BOL.  Bump the schema version of the object to achieve this.
			
	    -- LOCK, CHECK PERMISSION, BUMP SCHEMA FOR RECOMPILE  --
		EXEC %%Object(MultiName = @objname).LockMatchID(ID = @objid, Exclusive = 1, BindInternal = 0)
		if @@error <> 0
		begin
			COMMIT TRANSACTION
			raiserror(15165,-1,-1 ,@objname)
	        return @@error
		end
	end
	end
		
	COMMIT TRANSACTION
	raiserror(15070,-1,-1,@objname)
	return (0) -- sp_recompile
