USE [master]
GO

/****** Object:  StoredProcedure [dbo].[sp_sqlmonitor]    Script Date: 13/08/2015 15:27:59 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE PROCEDURE [dbo].[sp_sqlmonitor]
	(@RETORNO NVARCHAR(60))
AS
BEGIN
	--DECLARE @RETORNO NVARCHAR(60)
	--SET @RETORNO = 'Hostname'
	--SET @RETORNO = 'OSVersion'
	--SET @RETORNO = 'SQLVersion'
	--SET @RETORNO = 'UpTime'
	--SET @RETORNO = 'JobStatus'
	--SET @RETORNO = 'BackupFULL'
	--SET @RETORNO = 'BackupDIFF'
	--SET @RETORNO = 'BackupLOG'
	--SET @RETORNO = 'BatchRequests'
	--SET @RETORNO = 'TotalSessions'
	--SET @RETORNO = 'ActiveSessions'
	--SET @RETORNO = 'SQLMemoryKB'
	--SET @RETORNO = 'BufferCacheSizeKB'
	--SET @RETORNO = 'BufferCacheHitRatio'
	--SET @RETORNO = 'PageLifeExpectancy'
	--SET @RETORNO = 'ProcedureCacheSizeKB'
	--SET @RETORNO = 'PlanCacheHitRatio'
	--SET @RETORNO = 'Databases'
	--SET @RETORNO = 'FileGroups'
	--SET @RETORNO = 'DataFilesQuant'
	--SET @RETORNO = 'LogFilesQuant'
	--SET @RETORNO = 'DataFilesUsedKB'
	--SET @RETORNO = 'LogFilesUsedKB'
	--SET @RETORNO = 'DataFilesUsedPercent'
	--SET @RETORNO = 'LogFilesUsedPercent'
	--SET @RETORNO = 'BlockedSessions'
	--SET @RETORNO = 'DataFilesSpace'	
	--SET @RETORNO = 'LogFilesSpace'

	IF @RETORNO = 'Hostname'
	BEGIN
		SELECT @@SERVERNAME AS [RETORNO]
	END

	IF @RETORNO = 'OSVersion'
	BEGIN
		SELECT 
			CASE RIGHT(SUBSTRING(@@VERSION, CHARINDEX('Windows NT', @@VERSION), 14), 3)
			WHEN 6.3 THEN 'Windows Server 2012 R2'
			WHEN 6.2 THEN 'Windows Server 2012'
			WHEN 6.1 THEN 'Windows Server 2008 R2'
			WHEN 6.0 THEN 'Windows Server 2008'
			WHEN 5.2 THEN 'Windows Server 2003 R2'
			WHEN 5.1 THEN 'Windows Server 2003'
		END  AS [RETORNO]
	END

	IF @RETORNO = 'SQLVersion'
	BEGIN
		SELECT LEFT(@@VERSION,CHARINDEX('-',@@VERSION)- 2) AS [RETORNO]	
	END

	IF  @RETORNO = 'UpTime'
	BEGIN
		SELECT DATEDIFF(SS,sqlserver_start_time,GETDATE()) AS [RETORNO] FROM sys.dm_os_sys_info
	END

	IF @RETORNO = 'JobStatus'
	BEGIN
		SELECT COUNT(*) AS [RETORNO] FROM msdb.dbo.SysJobServers WHERE last_run_outcome = 0
	END

	IF @RETORNO = 'BackupFULL'
	BEGIN
		DECLARE @LAST_SUNDAY AS DATETIME
		SELECT @LAST_SUNDAY = CONVERT(NVARCHAR,DATEADD(DAY,1-DATEPART(DW, GETDATE()), GETDATE()),110)

		SELECT COUNT(*) AS [RETORNO]
		FROM
			(
				SELECT database_name, MAX(backup_start_date) AS [backup_start_date]
				FROM msdb.dbo.backupset a
					INNER JOIN master.sys.databases db on a.database_name = db.name
				WHERE a.type = 'D' AND db.state = 0 AND db.is_read_only = 0 AND db.name NOT IN ('model','tempdb') AND sys.fn_hadr_backup_is_preferred_replica(db.name) = 1
				GROUP BY database_name
			) a
		WHERE a.backup_start_date < @LAST_SUNDAY
	END


	IF @RETORNO = 'BackupDIFF'
	BEGIN
		SELECT COUNT(*) AS [RETORNO]
		FROM
			(
				SELECT database_name, MAX(backup_start_date) AS [backup_start_date]
				FROM msdb.dbo.backupset a
					INNER JOIN master.sys.databases db on a.database_name = db.name
				WHERE type = 'I' AND  db.state = 0 AND db.is_read_only = 0 AND db.name NOT IN ('model','tempdb') AND sys.fn_hadr_backup_is_preferred_replica(db.name) = 1 AND db.database_id > 4
				GROUP BY database_name
			) a
		WHERE a.backup_start_date < CONVERT(NVARCHAR,GETDATE(),110)
	END

	IF @RETORNO = 'BackupLOG'
	BEGIN
		SELECT COUNT(*) AS [RETORNO]
		FROM
			(
				SELECT database_name, MAX(backup_start_date) AS [backup_start_date]
				FROM msdb.dbo.backupset a
					INNER JOIN master.sys.databases db on a.database_name = db.name
				WHERE type = 'L' AND db.state = 0 AND db.is_read_only = 0 AND db.name NOT IN ('model','tempdb') AND db.recovery_model = 1 AND sys.fn_hadr_backup_is_preferred_replica(db.name) = 1
				GROUP BY database_name
			) a
		WHERE a.backup_start_date < CONVERT(NVARCHAR,GETDATE(),110)
	END

	IF @RETORNO =  'BatchRequests'
	BEGIN
		DECLARE @REQUESTSPERSECONDSAMPLE1 AS BIGINT
		DECLARE @REQUESTSPERSECONDSAMPLE2 AS BIGINT

		SELECT @REQUESTSPERSECONDSAMPLE1 = cntr_value FROM master.sys.dm_os_performance_counters WHERE object_name LIKE 'SQLServer:SQL Statistics%' AND counter_name LIKE 'Batch Requests%'
		WAITFOR DELAY '00:00:01'
		SELECT @REQUESTSPERSECONDSAMPLE2 = cntr_value FROM master.sys.dm_os_performance_counters WHERE object_name LIKE 'SQLServer:SQL Statistics%' AND counter_name LIKE 'Batch Requests%'
		SELECT @REQUESTSPERSECONDSAMPLE2 - @REQUESTSPERSECONDSAMPLE1  AS [RETORNO]
	END

	IF @RETORNO = 'TotalSessions'
	BEGIN
		SELECT COUNT(*)  AS [RETORNO] FROM sys.dm_exec_sessions WHERE is_user_process = 1
	END

	IF @RETORNO = 'ActiveSessions'
	BEGIN
		SELECT COUNT(*)  AS [RETORNO] FROM sys.dm_exec_sessions WHERE is_user_process = 1 AND status = 'Running'
	END

	IF @RETORNO = 'SQLMemoryKB'
	BEGIN
		SELECT (cntr_value) AS [RETORNO]
		FROM sys.dm_os_performance_counters
		WHERE object_name LIKE 'SQLServer:Memory Manager%' AND counter_name LIKE 'Total Server Memory (KB)%'
	END

	IF @RETORNO = 'BufferCacheSizeKB'
	BEGIN
		SELECT COUNT(page_id) * 8 AS [RETORNO] FROM sys.dm_os_buffer_descriptors
	END

	IF @RETORNO = 'BufferCacheHitRatio'
	BEGIN
		DECLARE @BUFFERCACHEHITRATIO AS FLOAT
		DECLARE @BUFFERCACHEHITRATIOBASE AS FLOAT
	
		SELECT @BUFFERCACHEHITRATIO = cntr_value
		FROM sys.dm_os_performance_counters
		WHERE object_name = 'SQLServer:Buffer Manager' AND counter_name =  'Buffer cache hit ratio'

		SELECT @BUFFERCACHEHITRATIOBASE = cntr_value
		FROM sys.dm_os_performance_counters
		WHERE object_name = 'SQLServer:Buffer Manager' AND counter_name =  'Buffer cache hit ratio Base'

		SELECT (@BUFFERCACHEHITRATIO / @BUFFERCACHEHITRATIOBASE)*100 AS [RETORNO]
	END
	
	IF @RETORNO = 'PageLifeExpectancy'
	BEGIN
		SELECT cntr_value AS [RETORNO]
		FROM sys.dm_os_performance_counters
		WHERE object_name = 'SQLServer:Buffer Manager' AND counter_name = 'Page life expectancy'
	END

	IF @RETORNO = 'ProcedureCacheSizeKB'
	BEGIN
		SELECT SUM(CAST(size_in_bytes AS bigint))/1024 AS [RETORNO]
		FROM sys.dm_exec_cached_plans
		WHERE size_in_bytes > = 1
	END

	IF @RETORNO = 'PlanCacheHitRatio'
	BEGIN
		DECLARE @PLANCACHEHITRATIO AS FLOAT
		DECLARE @PLANCACHEHITRATIOBASE AS FLOAT
	
		SELECT @PLANCACHEHITRATIO = cntr_value
		FROM sys.dm_os_performance_counters
		WHERE object_name = 'SQLServer:Plan Cache' AND counter_name = 'Cache Hit Ratio' AND instance_name = '_Total'

		SELECT @PLANCACHEHITRATIOBASE = cntr_value
		FROM sys.dm_os_performance_counters
		WHERE object_name = 'SQLServer:Plan Cache' AND counter_name = 'Cache Hit Ratio Base' AND instance_name = '_Total'

		SELECT (@PLANCACHEHITRATIO / @PLANCACHEHITRATIOBASE)*100 AS [RETORNO]
	END

	IF @RETORNO = 'Databases'
	BEGIN
		SELECT COUNT(*) FROM sys.databases WHERE database_id > 4
	END

	IF @RETORNO = 'FileGroups'
	BEGIN
		CREATE TABLE  #FGS  (  db_name sysname, name sysname ) 
		EXEC  sp_msforeachdb  ' use ? insert into #FGS select db_name(), name from sys.filegroups' 
	
		SELECT  COUNT(*) AS [RETORNO]  
		FROM  #FGS
		WHERE db_name NOT IN ('master','tempdb','model','msdb')
		DROP TABLE #FGS
	END

	IF @RETORNO = 'DataFilesQuant'
	BEGIN
		SELECT COUNT(*) AS [RETORNO]
		FROM sys.master_files
		WHERE database_id > 4 AND type = 0
	END

	IF @RETORNO = 'LogFilesQuant'
	BEGIN
		SELECT COUNT(*) AS [RETORNO]
		FROM sys.master_files
		WHERE database_id > 4 AND type = 1
	END

	IF @RETORNO = 'DataFilesUsedKB'
	BEGIN
		declare @commandDataFilesUsedKB as varchar(4000)
		declare @dbnameDataFilesUsedKB varchar(60)
		declare @resultDataFilesUsedKB as table
			(
				[database_id] int,
				[type] int,
				[size] int,
				[used] int,
				[free] int	
			)
		declare vcursor cursor static for
			select name
			from sys.databases
			where state=0 and is_read_only = 0 and name not in ('model','tempdb','master','msdb')

		open vcursor
		fetch next from vcursor into @dbnameDataFilesUsedKB
		while @@fetch_status = 0
		begin
			select @commandDataFilesUsedKB = 
						'use '+@dbnameDataFilesUsedKB+' select database_id database_id, type type, size size, fileproperty(name, ''spaceused'') used, size - fileproperty(name, ''spaceused'') free
						from sys.master_files
						where db_name(database_id) = ''' + @dbnameDataFilesUsedKB + ''''
			insert into @resultDataFilesUsedKB
			exec (@commandDataFilesUsedKB)
			fetch next from vcursor into @dbnameDataFilesUsedKB
		end

		close vcursor
		deallocate vcursor

		select (sum(used))*8 AS [RETORNO]
		from @resultDataFilesUsedKB
		where type = 0
	END

	IF @RETORNO = 'LogFilesUsedKB'
	BEGIN
		declare @commandLogFilesUsedKB as varchar(4000)
		declare @dbnameLogFilesUsedKB varchar(60)
		declare @resultLogFilesUsedKB as table
			(
				[database_id] int,
				[type] int,
				[size] int,
				[used] int,
				[free] int	
			)
		declare vcursor cursor static for
			select name
			from sys.databases
			where state=0 and is_read_only = 0 and name not in ('model','tempdb','master','msdb')

		open vcursor
		fetch next from vcursor into @dbnameLogFilesUsedKB
		while @@fetch_status = 0
		begin
			select @commandLogFilesUsedKB = 
						'use '+@dbnameLogFilesUsedKB+' select database_id database_id, type type, size size, fileproperty(name, ''spaceused'') used, size - fileproperty(name, ''spaceused'') free
						from sys.master_files
						where db_name(database_id) = ''' + @dbnameLogFilesUsedKB + ''''
			insert into @resultLogFilesUsedKB
			exec (@commandLogFilesUsedKB)
			fetch next from vcursor into @dbnameLogFilesUsedKB
		end

		close vcursor
		deallocate vcursor

		select (sum(used))*8 AS [RETORNO]
		from @resultLogFilesUsedKB
		where type = 1
	END

	IF @RETORNO = 'DataFilesUsedPercent'
	BEGIN
		declare @commandDataFilesUsedPercent as varchar(4000)
		declare @dbnameDataFilesUsedPercent varchar(60)
		declare @resultDataFilesUsedPercent as table
			(
				[database_id] int,
				[type] int,
				[size] int,
				[used] int,
				[free] int	
			)
		declare vcursor cursor static for
			select name
			from sys.databases
			where state=0 and is_read_only = 0 and name not in ('model','tempdb','master','msdb')

		open vcursor
		fetch next from vcursor into @dbnameDataFilesUsedPercent
		while @@fetch_status = 0
		begin
			select @commandDataFilesUsedPercent = 
						'use '+@dbnameDataFilesUsedPercent+' select database_id database_id, type type, size size, fileproperty(name, ''spaceused'') used, size - fileproperty(name, ''spaceused'') free
						from sys.master_files
						where db_name(database_id) = ''' + @dbnameDataFilesUsedPercent + ''''
			insert into @resultDataFilesUsedPercent
			exec (@commandDataFilesUsedPercent)
			fetch next from vcursor into @dbnameDataFilesUsedPercent
		end

		close vcursor
		deallocate vcursor

		select cast(cast(sum(used) as float)/cast(sum(size) as float) * 100 as decimal(10,2)) AS [RETORNO]
		from @resultDataFilesUsedPercent
		where type = 0
	END

	IF @RETORNO = 'LogFilesUsedPercent'
	BEGIN
		declare @commandLogFilesUsedPercent as varchar(4000)
		declare @dbnameLogFilesUsedPercent varchar(60)
		declare @resultLogFilesUsedPercent as table
			(
				[database_id] int,
				[type] int,
				[size] int,
				[used] int,
				[free] int	
			)
		declare vcursor cursor static for
			select name
			from sys.databases
			where state=0 and is_read_only = 0 and name not in ('model','tempdb','master','msdb')

		open vcursor
		fetch next from vcursor into @dbnameLogFilesUsedPercent
		while @@fetch_status = 0
		begin
			select @commandLogFilesUsedPercent = 
						'use '+@dbnameLogFilesUsedPercent+' select database_id database_id, type type, size size, fileproperty(name, ''spaceused'') used, size - fileproperty(name, ''spaceused'') free
						from sys.master_files
						where db_name(database_id) = ''' + @dbnameLogFilesUsedPercent + ''''
			insert into @resultLogFilesUsedPercent
			exec (@commandLogFilesUsedPercent)
			fetch next from vcursor into @dbnameLogFilesUsedPercent
		end

		close vcursor
		deallocate vcursor

		select cast(cast(sum(used) as float)/cast(sum(size) as float) * 100 as decimal(10,2)) AS [RETORNO]
		from @resultLogFilesUsedPercent
		where type = 1
	END


	IF @RETORNO = 'BlockedSessions'
	BEGIN
		SELECT COUNT(*) AS RETORNO FROM sys.dm_exec_requests WHERE blocking_session_id > 0
	END

	IF @RETORNO = 'DataFilesSpace'
	BEGIN
		CREATE TABLE  #Datafiles  (db_name sysname, used_space float )

		EXEC  sp_msforeachdb  ' use ?; 
								insert into #Datafiles 
								select
										db_name(database_id) [database],
										avg(cast(cast(fileproperty(a.name, ''spaceused'') as float)/cast(size as float) * 100 as decimal(10,1))) [used %]
									from 
										sys.master_files a
									where 
										type = 0 and database_id = db_id()  /* 0 = Datafile / 1 = Logfile */
									group by 
										db_name(database_id)' 
	
		SELECT  COUNT(*) AS [RETORNO]  
		FROM  #Datafiles
		WHERE used_space >= 75
		DROP TABLE #Datafiles
	END

	IF @RETORNO = 'LogFilesSpace'
	BEGIN
		CREATE TABLE  #Logfiles  (db_name sysname, used_space float )

		EXEC  sp_msforeachdb  ' use ?; 
								insert into #Logfiles 
								select
										db_name(database_id) [database],
										avg(cast(cast(fileproperty(a.name, ''spaceused'') as float)/cast(size as float) * 100 as decimal(10,1))) [used %]
									from 
										sys.master_files a
									where 
										type = 1 and database_id = db_id()  /* 0 = Datafile / 1 = Logfile */
									group by 
										db_name(database_id)' 
	
		SELECT  COUNT(*) AS [RETORNO]  
		FROM  #Logfiles
		WHERE used_space >= 75
		DROP TABLE #Logfiles
	END

END






GO


