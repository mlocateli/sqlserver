/****** Object:  StoredProcedure [dbo].[spu_otimizacao_necessaria]    Script Date: 02/22/2012 10:49:48 ******/

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER OFF
GO

create procedure [dbo].[spu_ibm_optimization](@maxfrag decimal = 10) as

set nocount on
set arithabort on
set quoted_identifier on

declare @DBName varchar(100)

set @DBName = db_name()

print '-- *************************************************************************************** ' + char(13)
print '--  OTIMIZANDO O BANCO: ' + @DBName + ' - ' + convert(varchar(30), getdate(), 13) + char(13)
print '-- *************************************************************************************** ' + char(13)

-- select the indexes with
declare @ListaIndices table(schema_nome varchar(250), tabela_nome varchar(250), indice_nome varchar(250), indice_tipo varchar(250), usado_kb int, numero_linhas int, fragmentacao decimal(9,2));
insert @ListaIndices
select sch.name [schema_nome],
	obj.name [tabela_nome],
	idx.name [indice_nome],
	idx.type_desc [indice_tipo],
	part.used_page_count*8 [usado_kb], -- the pages spo with 8Kb
	part.row_count [numero_linhas],
	CONVERT(DECIMAL(9,2),frag.avg_fragmentation_in_percent) [fragmentacao]
from sys.dm_db_partition_stats part       
	join sys.objects obj on part.object_id = obj.object_id
	join sys.schemas sch on obj.schema_id = sch.schema_id      
	left join sys.indexes idx on part.object_id = idx.object_id and part.index_id = idx.index_id      
	left join sys.dm_db_index_physical_stats(db_id(),null,null,null,null) frag on part.object_id = frag.object_id and part.index_id = frag.index_id
where obj.is_ms_shipped = 0 and frag.page_count > 100  
order by [schema_nome],[tabela_nome],[indice_nome];

-- charge the cursor only with the indexes mojar than 10% of fragmentation
declare maintCursor cursor for   
	select	'alter index [' + [indice_nome] + '] on [' + [schema_nome] + '].[' + [tabela_nome] + ']',
		'update statistics [' + @DBName + '].[' + [schema_nome] + '].[' + [tabela_nome] + ']',
		'sp_recompile N' + '''' + '[' + @DBName + '].[' + [schema_nome] + '].[' + [tabela_nome] + ']' + '''',
		fragmentacao
	from @ListaIndices 
	where fragmentacao > @maxfrag;

declare @stmt_reindexa varchar(max);
declare @stmt_estatist varchar(max);
declare @stmt_recompil varchar(max);
declare @stmt_updateus varchar(max);
declare @frag float;

open maintCursor
fetch next from maintCursor into @stmt_reindexa, @stmt_estatist, @stmt_recompil, @frag
while @@fetch_status = 0
begin   

	if @frag > 30
		set @stmt_reindexa = @stmt_reindexa + ' rebuild with (fillfactor = 90)';
	else
		set @stmt_reindexa = @stmt_reindexa + ' reorganize';

	print (@stmt_reindexa)
	exec (@stmt_reindexa)

	print (@stmt_estatist)
	exec (@stmt_estatist)

	print (@stmt_recompil+char(13))
	exec (@stmt_recompil)

	fetch next from maintCursor into @stmt_reindexa, @stmt_estatist, @stmt_recompil, @frag

end

close maintCursor
deallocate maintCursor

set @stmt_updateus = 'DBCC UPDATEUSAGE (0) WITH NO_INFOMSGS'
print (@stmt_updateus)
exec (@stmt_updateus)

print '-- *************************************************************************************** ' + char(13)
print '--  FIM DO PROCESSO DE REINDEXACAO NO BANCO ' + db_name() + ' - ' + convert(varchar(30), getdate(), 13) + char(13)
print '-- *************************************************************************************** ' + char(13) + char(13)

set nocount off
GO


 