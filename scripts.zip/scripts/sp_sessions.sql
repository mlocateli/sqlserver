use master
go

CREATE procedure [dbo].[sp_sessions]    
(    
 @order_by varchar(200) = 'session_id',    
 @session_id varchar(200) = '%%',    
 @login_name varchar(200) = '%%',    
 @status varchar(200) = '%%',    
 @database varchar(60) = '%%',    
 @login_time varchar(200) = '%%',    
 @host_name varchar(200) = '%%',    
 @program_name varchar(200) = '%%',    
 @host_process_id varchar(200) = '%%',    
 @last_request_start_time varchar(200) = '%%',    
 @last_request_end_time varchar(200) = '%%',    
 @memory_usage varchar(200) = '%%',    
 @client_net_address varchar(200) = '%%'    
)    
    
as     
begin    
 declare @query nvarchar(max)    
 declare @query2 nvarchar(max)    
     
 set @query = 'select    
  a.session_id,    
  a.login_name,    
  a.status,    
  db_name(c.dbid) [database],    
  a.login_time,    
  a.host_name,    
  a.program_name,    
  a.host_process_id,    
  a.last_request_start_time,    
  a.last_request_end_time,    
  a.memory_usage,    
  b.client_net_address    
 from    
  sys.dm_exec_sessions a    
  inner join sys.dm_exec_connections b on a.session_id = b.session_id    
  inner join sys.sysprocesses c on a.session_id = c.spid    
 where    
  a.is_user_process = 1 --user connection    
  and    
  a.session_id <> @@SPID    
  and    
  (a.session_id LIKE ''' + @session_id + ''' OR a.session_id IS NULL)    
  and    
  (a.login_name LIKE ''' + @login_name + ''' OR a.login_name IS NULL)    
  and    
  (a.status LIKE ''' + @status + ''' OR a.status IS NULL)    
  and    
  (db_name(c.dbid) LIKE ''' + @database + ''' OR a.status IS NULL)    
  and    
  (a.login_time LIKE ''' + @login_time + ''' OR a.login_time IS NULL)    
  and    
  (a.host_name LIKE ''' + @host_name + ''' OR a.host_name IS NULL)    
  and    
  (a.program_name LIKE ''' + @program_name + ''' OR a.program_name IS NULL)    
  and    
  (a.host_process_id LIKE ''' + @host_process_id + ''' OR a.host_process_id IS NULL)    
  and    
  (a.last_request_start_time LIKE ''' + @last_request_start_time + ''' OR a.last_request_start_time IS NULL)    
  and    
  (a.last_request_end_time LIKE ''' + @last_request_end_time + ''' OR a.last_request_end_time IS NULL)    
  and    
  (a.memory_usage LIKE ''' + @memory_usage + ''' OR a.memory_usage IS NULL)    
  and    
  (b.client_net_address LIKE ''' + @client_net_address + ''' OR b.client_net_address IS NULL)    
 order by ' + @order_by    
    
    
 set @query2 = 'select a.login_name, a.status, count(*) total    
 from    
  sys.dm_exec_sessions a    
 where    
  a.is_user_process = 1 --user connection    
  and    
  a.session_id <> @@SPID    
 group by a.login_name, a.status    
 order by a.login_name, a.status'    
    
 --print (@query)    
 exec (@query)    
 --exec (@query2)    
end    
    
  
  