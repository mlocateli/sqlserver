CREATE PROC [sys].[sp_readerrorlog]( 
   @p1 INT = 0, 
   @p2 INT = NULL, 
   @p3 VARCHAR(255) = NULL, 
   @p4 VARCHAR(255) = NULL) 
AS 
BEGIN 

   IF (NOT IS_SRVROLEMEMBER(N'securityadmin') = 1) 
   BEGIN 
      RAISERROR(15003,-1,-1, N'securityadmin') 
      RETURN (1) 
   END 
    
   IF (@p2 IS NULL) 
       EXEC sys.xp_readerrorlog @p1 
   ELSE 
       EXEC sys.xp_readerrorlog @p1,@p2,@p3,@p4 
END 

-- @p1 = Value of error log file you want to read: 0 = current, 1 = Archive #1, 2 = Archive #2, etc...
-- @p2 = Log file type: 1 or NULL = error log, 2 = SQL Agent log
-- @p3 = Search string 1: String one you want to search for
-- @p4 = Search string 2: String two you want to search for to further refine the results

EXEC sp_readerrorlog 0, 1, 'app_mti_monitor'


