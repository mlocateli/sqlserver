
-- SQL SERVER � Service Broker and CAP_CPU_PERCENT � Limiting SQL Server Instances to CPU Usage

select * --name,max_cpu_percent,max_memory_percent 
from sys.dm_resource_governor_resource_pools

-- Creating Resource Pool for Report Server
-- https://docs.microsoft.com/en-us/sql/t-sql/statements/create-resource-pool-transact-sql?view=sql-server-2017

CREATE RESOURCE POOL ReportServerPool
WITH
( MIN_CPU_PERCENT=0,
MAX_CPU_PERCENT=30,
CAP_CPU_PERCENT=40,
MIN_MEMORY_PERCENT=0,
MAX_MEMORY_PERCENT=30)
GO

-- https://docs.microsoft.com/en-us/sql/t-sql/statements/alter-resource-pool-transact-sql?view=sql-server-2017
ALTER RESOURCE POOL ReportServerPool
WITH  
     ( CAP_CPU_PERCENT = 50);  
GO  

ALTER RESOURCE GOVERNOR RECONFIGURE;  
GO  

