-- Rodar no servidor principal
USE [master]
GO
ALTER DATABASE <Database Name> SET PARTNER FAILOVER
GO

-- Rodar no servidor mirror
USE [master]
GO
ALTER DATABASE <Database Name> SET PARTNER FORCE_SERVICE_ALLOW_DATA_LOSS
GO

-- Pausa o espelhamento
USE [master]
GO
ALTER DATABASE <Database Name> SET PARTNER SUSPEND
GO

-- Resume o espelhamento
USE [master]
GO
ALTER DATABASE <Database Name> SET PARTNER RESUME
GO

--desliga o espelhamento
USE [master]
GO
ALTER DATABASE <Database Name> SET PARTNER OFF 
GO

-- volta a base de (restoring...)
RESTORE DATABASE <Database Name>
WITH RECOVERY
GO

