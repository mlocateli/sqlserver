--USE DBMON000

ALTER PROCEDURE sp_get_exclude_path
AS

	-- Cria tabela tempor�ria
	IF (OBJECT_ID('Exclude_Path_GNA') IS NOT NULL)  
	DROP TABLE Exclude_Path_GNA

	CREATE TABLE Exclude_Path_GNA (
		ServerName varchar(255),
		DatabaseName varchar(255),
		DatabasePath varchar(255)
	)
	
	declare @servername varchar(60), @instancename varchar(255), @databasename varchar(255)
	declare @usuario varchar(20), @senha varchar(20)
	declare @strsql varchar(8000), @strsql2 varchar(8000)
	
	declare cr_servidor CURSOR FAST_FORWARD READ_ONLY  FOR
		select servidor, usuario, senha 
		from dbmon000..servers_gna
		where status = 0 --and servidor like '%sqlwhi02.ga.local\test%'
		order by servidor

	OPEN cr_servidor 
	FETCH NEXT FROM cr_servidor
	INTO @servername, @usuario, @senha

		WHILE @@FETCH_STATUS = 0
		BEGIN

			declare @name varchar(150), @dbid smallint
			--print @servidor

			-- insere os dados na tabela temporaria	
			set @strsql =  'insert into Exclude_Path_GNA SELECT '''+@servername+''', *  FROM OPENROWSET ( ''SQLOLEDB'',''' + @servername+''';'''+@usuario+''';'''+@senha+''',
			''select name as database_name, filename as database_path
				from master..sysdatabases
				order by name '' )'
			
			print @strsql
			--exec (@strsql)

			FETCH NEXT FROM cr_servidor
			INTO @servername, @usuario, @senha  
		END
	CLOSE cr_servidor
	DEALLOCATE cr_servidor
	
	--ALTER TABLE ListOfAllDatabases_GNA ADD DatabaseSize INT;	
	--DROP TABLE Exclude_Path_GNA
	
GO

