--USE DBMON000

ALTER PROCEDURE sp_get_database_size_GNA
AS

	-- Cria tabela tempor�ria
	IF (OBJECT_ID('ListOfAllDatabases_GNA') IS NOT NULL)  
	DROP TABLE ListOfAllDatabases_GNA

	CREATE TABLE ListOfAllDatabases_GNA (
		ServerName varchar(255),
		DatabaseName varchar(255)
	)
	
	declare @servername varchar(60), @instancename varchar(255), @databasename varchar(255)
	declare @usuario varchar(20), @senha varchar(20)
	declare @strsql varchar(8000), @strsql2 varchar(8000)
	
	declare cr_servidor CURSOR FAST_FORWARD READ_ONLY  FOR
		select servidor, usuario, senha 
		from dbmon000..servers_gna
		where status = 0 --and servidor like '%sqlwhi02.ga.local\test%'
		order by servidor

	OPEN cr_servidor 
	FETCH NEXT FROM cr_servidor
	INTO @servername, @usuario, @senha

		WHILE @@FETCH_STATUS = 0
		BEGIN

			declare @name varchar(150), @dbid smallint
			--print @servidor

			-- insere os dados na tabela temporaria	
			set @strsql =  'insert into ListOfAllDatabases_GNA SELECT '''+@servername+''', name  FROM OPENROWSET ( ''SQLOLEDB'',''' + @servername+''';'''+@usuario+''';'''+@senha+''',
			''select name from master..sysdatabases 
			where name not in (''''tempdb'''', ''''model'''')
			and status not in (''''536'''', ''''3088'''', ''''528'''', ''''3096'''', ''''4197400'''', ''''1048'''', ''''1077936144'''')'' )'
			--('536', '3088', '528', '3096', '4197400', '4197400', '1048', '4196376') ('2072','4196376')
			--print @strsql
			exec (@strsql)

			FETCH NEXT FROM cr_servidor
			INTO @servername, @usuario, @senha  
		END
	CLOSE cr_servidor
	DEALLOCATE cr_servidor
	
	ALTER TABLE ListOfAllDatabases_GNA ADD DatabaseSize INT;
	
	DECLARE Cursor2 CURSOR FAST_FORWARD READ_ONLY  FOR
		select servername, databasename
		from dbmon000..ListOfAllDatabases_GNA
		order by servername, databasename

	OPEN Cursor2 
	FETCH NEXT FROM Cursor2
	INTO @servername, @databasename

		WHILE @@FETCH_STATUS = 0
		BEGIN

			--declare @name varchar(150), @dbid smallint
			--print @servidor
			
			set @usuario = 'sa_ibm'
			set @senha = 'hebfUZa0Hg6zJX'
			-- insere os dados na tabela temporaria	
			set @strsql2 =  'INSERT INTO DBMON000..historico_dbs 
			SELECT '''+@servername+''' as servidor, getdate() as data, nomeDB, utilizadoDB, ''GNA'' as Contrato
			FROM OPENROWSET ( ''SQLOLEDB'',''' + @servername+''';'''+@usuario+''';'''+@senha+''',
			''select '''''+@databasename+''''' as nomeDB,  SUM((cast(size as bigint) * cast(8192 as bigint) / cast(1048576 as bigint))) as utilizadoDB 
			from ['+@databasename+'].dbo.sysfiles where filename like ''''%.mdf%'''' or filename like ''''%.MDF%'''' or filename like ''''%.ndf%'''' or filename like ''''%.NDF%'''''')'

			--print @strsql2
			exec (@strsql2)

		FETCH NEXT FROM Cursor2
		INTO @servername, @databasename 
		END
	CLOSE Cursor2
	DEALLOCATE Cursor2
	
	DROP TABLE ListOfAllDatabases_GNA
	
GO

