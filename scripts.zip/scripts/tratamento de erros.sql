
BEGIN TRY
    -- Generate a divide-by-zero error.
    SELECT 1/0;
END TRY
BEGIN CATCH
    SELECT
        ERROR_NUMBER() AS ErrorNumber
        ,ERROR_SEVERITY() AS ErrorSeverity
        ,ERROR_STATE() AS ErrorState
        ,ERROR_PROCEDURE() AS ErrorProcedure
        ,ERROR_LINE() AS ErrorLine
        ,ERROR_MESSAGE() AS ErrorMessage;
END CATCH;
GO
 
SELECT 987654 * 135792
IF @@ERROR <> 0
PRINT 'OCORREU ERRO'

EXECUTE master.dbo.xp_sqlmaint N'-PlanID 25AA4E98-2E37-4DF3-82A9-757ED2634F68 -WriteHistory  -VrfyBackup -BkUpMedia DISK -BkUpLog "D:\backup" -DelBkUps 2DAYS -CrBkSubDir -BkExt "TRN"'
IF @@ERROR <> 0
    PRINT 'A constraint error has occurred' 
GO 


select * from servers_gna

