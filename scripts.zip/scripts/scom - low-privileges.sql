
-- adiciona permissao para usuario do monitoramento no MS SQL Server 2017
-- SICREDI\app_adm_ops

USE master
GO

GRANT VIEW SERVER STATE TO [SICREDI\app_adm_ops]
GRANT VIEW ANY DATABASE TO [SICREDI\app_adm_ops]
GRANT VIEW ANY DEFINITION TO [SICREDI\app_adm_ops]

GRANT EXECUTE ON xp_readerrorlog TO [SICREDI\app_adm_ops]

USE MSDB
GO

GRANT EXECUTE ON msdb.dbo.sp_help_job to [SICREDI\app_adm_ops] 
GRANT EXECUTE ON msdb.dbo.sp_help_jobactivity to [SICREDI\app_adm_ops] 
GRANT SELECT ON sysjobs_view to [SICREDI\app_adm_ops] 
GRANT SELECT ON sysschedules to [SICREDI\app_adm_ops] 
GRANT SELECT ON sysjobschedules to [SICREDI\app_adm_ops] 
GRANT SELECT ON log_shipping_monitor_history_detail to [SICREDI\app_adm_ops] 
GRANT SELECT ON log_shipping_monitor_secondary to [SICREDI\app_adm_ops] 
GRANT SELECT ON log_shipping_secondary_databases to [SICREDI\app_adm_ops] 
GRANT SELECT ON log_shipping_monitor_primary to [SICREDI\app_adm_ops] 
GRANT SELECT ON log_shipping_primary_databases to [SICREDI\app_adm_ops]

USE MSDB
GO

ALTER ROLE [SQLAgentReaderRole] ADD MEMBER [SICREDI\app_adm_ops]
ALTER ROLE [PolicyAdministratorRole] ADD MEMBER [SICREDI\app_adm_ops]
