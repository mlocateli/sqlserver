USE [master]
GO

CREATE PROCEDURE [dbo].[RebuildIndexesV2] (
	@maxfrag float = 15.0
	, @maxdensity float = 90.0
	, @databasename varchar(255))

AS 

SET NOCOUNT ON;
DECLARE @schemaname sysname;
DECLARE @objectname sysname;
DECLARE @indexname sysname;
DECLARE @indexid int; 
DECLARE @currentfrag float;
DECLARE @currentdensity float;
DECLARE @partitionnum varchar(10);
DECLARE @partitioncount bigint;
DECLARE @indextype varchar(18);
DECLARE @updatecommand varchar(max);
DECLARE @command varchar(max);
DECLARE @fill_factor tinyint;
DECLARE @ExecutionID uniqueidentifier;
Set @ExecutionID = NEWID();
Declare @creationDate datetime
Set @creationDate = getdate()
Declare @erroAbertura varchar(max)
Set @erroAbertura = ''

INSERT INTO dba.dbo.RebuildIndexHistory(
	ExecutionID, CreationDate, IndexID, Tableid,  IndexType, PartitionNumber, CurrentDensity, CurrentFragmentation, DatabaseId
	)
	SELECT
		@ExecutionID
		,@creationDate
		,fi.index_id 
		, fi.object_id 
		, fi.index_type_desc AS IndexType
		, cast(fi.partition_number as varchar(10)) AS PartitionNumber
		, fi.avg_page_space_used_in_percent AS CurrentDensity
		, fi.avg_fragmentation_in_percent AS CurrentFragmentation
		, db_id(@databasename)
	FROM sys.dm_db_index_physical_stats(db_id(@databasename), NULL, NULL, NULL, 'SAMPLED') AS fi 
	WHERE	(fi.avg_fragmentation_in_percent >= @maxfrag)
	--OR		(fi.avg_page_space_used_in_percent < @maxdensity and fi.avg_fragmentation_in_percent >= @maxfrag))
	AND		page_count> 8
	AND		fi.index_id > 0

--Assign the index names, schema names, table names and partition counts
SET @updatecommand = 'UPDATE w SET TableName = o.name, SchemaName = s.name, IndexName = i.Name, fill_factor = i.fill_factor 
	,PartitionCount = (SELECT COUNT(*) pcount
	FROM ' 
	+ QUOTENAME(@databasename) + '.sys.partitions p
	where  p.Object_id = w.Tableid 
	AND p.index_id = w.Indexid)
	FROM ' 
	+ QUOTENAME(@databasename) + '.sys.objects o INNER JOIN '
	+ QUOTENAME(@databasename) + '.sys.schemas s ON o.schema_id = s.schema_id 
	INNER JOIN dba.dbo.RebuildIndexHistory w ON o.object_id = w.tableid and ExecutionId = '''+convert(char(255),@ExecutionID)+''' INNER JOIN '
	+ QUOTENAME(@databasename) + '.sys.indexes i ON w.tableid = i.object_id and w.indexid = i.index_id';

	begin try
		EXEC(@updatecommand)
	end try
	begin catch
		Set @erroAbertura = ERROR_MESSAGE()
	end catch

--Declare the cursor for the list of tables, indexes and partitions to be processed.
--If the index is a clustered index, rebuild all of the nonclustered indexes for the table.
--If we are rebuilding the clustered indexes for a table, we can exclude the 
--nonclustered and specify ALL instead on the table

DECLARE rebuildindex CURSOR FOR 
	SELECT	QUOTENAME(IndexName) AS IndexName
			, TableName
			, SchemaName
			, IndexType
			, PartitionNumber
			, PartitionCount
			, CurrentDensity
			, CurrentFragmentation
			, fill_factor
	FROM	dba.dbo.RebuildIndexHistory
	where ExecutionID= convert(char(255),@ExecutionID)
	ORDER BY TableName, IndexID;

-- Open the cursor.
OPEN rebuildindex;

-- Loop through the tables, indexes and partitions.
FETCH NEXT
   FROM rebuildindex
   INTO @indexname, @objectname, @schemaname, @indextype, @partitionnum, @partitioncount, @currentdensity, @currentfrag, @fill_factor;

WHILE @@FETCH_STATUS = 0
	BEGIN
		if @erroAbertura <> ''
		begin
			UPDATE dba.dbo.RebuildIndexHistory SET  command = @erroAbertura, startRoutine = getdate(), stopRoutine = getdate() WHERE  CURRENT OF rebuildindex ;
		end else
		begin


			Set @command =''
			-- If the index is more heavily fragmented, issue a REBUILD.  Otherwise, REORGANIZE.
			IF @currentfrag between 5 and 30 -- Somente faz reorganize de indices com frag entre 5 e 30 - dietrich
			BEGIN;
				--if then fill factor is assigned and the density is less then or equal fill factor then does nothing on reorganiza
				if not((@fill_factor > 0) and (@currentdensity<=@fill_factor))
				begin
					SELECT @command = 'ALTER INDEX ' + @indexname + ' ON ' + QUOTENAME(@databasename) +'.' + QUOTENAME(@schemaname) + '.' + QUOTENAME(@objectname);
					SELECT @command = @command + ' REORGANIZE';
					IF @partitioncount > 1
						SELECT @command = @command + ' PARTITION=' + @partitionnum;
				end;
			END;

			IF @currentfrag > 30 --Rebuild apenas acima de 30%
			BEGIN;
				
				SELECT @command = 'ALTER INDEX ' + @indexname + ' ON ' + QUOTENAME(@databasename) +'.' + QUOTENAME(@schemaname) + '.' + QUOTENAME(@objectname);
				
				SELECT @command = @command + ' REBUILD ';

				if @fill_factor > 0
					Select @command = @command + ' WITH ( FILLFACTOR = ' + str(@fill_factor)+', MAXDOP=16)'
				else 
					Select @command = @command + ' WITH (MAXDOP=16)'

				IF @partitioncount > 1
					SELECT @command = @command + ' PARTITION=' + @partitionnum;

				END;
		
			if (@command = '' )
			begin
				delete dba.dbo.RebuildIndexHistory WHERE  CURRENT OF rebuildindex ;
			end	else
			begin
				UPDATE dba.dbo.RebuildIndexHistory SET  command = @command, startRoutine = getdate() WHERE  CURRENT OF rebuildindex ;
				
				begin try
					EXEC (@command);
				end try
				begin catch
					UPDATE dba.dbo.RebuildIndexHistory SET  command = ERROR_MESSAGE() WHERE  CURRENT OF rebuildindex ;
				end catch
				--waitfor delay '00:00:02';

				UPDATE dba.dbo.RebuildIndexHistory SET  stopRoutine = getdate() WHERE  CURRENT OF rebuildindex ;

				--PRINT 'Executed ' + @command+ '-- dens:'+str( @currentdensity)+' frag:'+str(@currentfrag)+' fillfactor:'+str(@fill_factor);
			end
		end --erro abertura
		FETCH NEXT FROM rebuildindex INTO @indexname, @objectname, @schemaname, @indextype, @partitionnum, @partitioncount, @currentdensity, @currentfrag, @fill_factor;
	END;
	
	

-- Close and deallocate the cursor.
CLOSE rebuildindex;
DEALLOCATE rebuildindex;


GO


