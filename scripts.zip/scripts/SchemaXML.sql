USE TK431Chapter8
GO

CREATE XML SCHEMA COLLECTION LogRecordSchema AS
'<?xml version="1.0" encoding="UTF-8"?>
<xsd:schema xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <xsd:element name="logRecord" type="logRecordType" />
        
		<xsd:simpleType name="flagEnum">
            <xsd:restriction base="xsd:string">
                <xsd:enumeration value="warning" />
                <xsd:enumeration value="information" />
                <xsd:enumeration value="failure" />
                <xsd:enumeration value="custom" />
			</xsd:restriction>
		</xsd:simpleType>

		<xsd:simpleType name="eventEnum">
            <xsd:restriction base="xsd:string">
                <xsd:enumeration value="appStart" />
                <xsd:enumeration value="appClose" />
                <xsd:enumeration value="logIn" />
                <xsd:enumeration value="logOut" />
			</xsd:restriction>
		</xsd:simpleType>

		<xsd:complexType name="logRecordType">
            <xsd:choice maxOccurs="unbounded">
                <xsd:element name="information" type="informationType" />
                <xsd:element name="error" type="errorType" />
                <xsd:element name="post" type="postType" />
			</xsd:choice>
			<xsd:attribute name="machine" type="xsd:string" />
			<xsd:attribute name="timestamp" type="xsd:dateTime" />
		</xsd:complexType>

		<xsd:complexType name="postType">
            <xsd:sequence>
                <xsd:element name="moreInformation" type="xsd:string" maxOccurs="1" minOccurs="0" />
			</xsd:sequence>
			<xsd:attribute name="eventType" type="eventEnum" />
		</xsd:complexType>

		<xsd:complexType name="informationType">
            <xsd:sequence>
                <xsd:element name="message" type="xsd:string" />
			</xsd:sequence>
			<xsd:attribute name="flag" type="flagEnum" />
		</xsd:complexType>

		<xsd:complexType name="errorType">
            <xsd:sequence>
                <xsd:element name="message" type="xsd:string" />
				<xsd:element name="module" type="xsd:string" />
			</xsd:sequence>
			<xsd:attribute name="number" type="xsd:int" />
		</xsd:complexType>
	</xsd:schema>';
GO

