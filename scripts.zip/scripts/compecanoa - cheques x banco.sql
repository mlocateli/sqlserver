
use compecanoa
go

-- select cheques para o banco Sicredi 748

SELECT count(*) FROM DOCSCANOA WITH(nolock)
WHERE CONVERT(CHAR(10), DATACAP,23)='2019-08-07'
and TRXCAP='0' 
and master.dbo.fn_varbintohexstr(NUMDOC) like '0x748%'


