DECLARE @version nvarchar(128);
SET @version = CAST(serverproperty('ProductVersion') AS nvarchar);
SET @version = CAST(SUBSTRING(@version, 1, CHARINDEX('.', @version) - 1) as int);

IF (@version >= 11) 
	BEGIN 
		WITH LastBackupDate ([Database], [Type], [Last Backup]) AS (    
			SELECT 
				sd.name,
				CASE
					WHEN type = 'D' THEN 'Full'
					WHEN type = 'I' THEN 'Differential'
					WHEN type = 'L' THEN 'Log'
				END as [Type], 
				max(backup_start_date) AS LastBackupDate    
			FROM 
				msdb.dbo.backupset bs INNER JOIN 
				master.sys.databases sd 
					ON bs.database_name = sd.name    
			WHERE 
				TYPE IN ('D','I','L') AND 
				sd.state = 0 AND 
				bs.backup_start_date > DATEADD(DD, -90,GETDATE())    
			GROUP BY 
				sd.name, 
				type
			)    
		SELECT [Database], [Type], [Last Backup]     
		FROM LastBackupDate    
		WHERE 
			[Last Backup] <= DATEADD(day, -7, GETDATE()) AND 
			sys.fn_hadr_backup_is_preferred_replica([Database]) = 1 
		ORDER BY [Database]
	END
ELSE
	BEGIN
		WITH LastBackupDate ([Database], [Type], [Last Backup])    
			AS (    
				SELECT 
					sd.name, 
					type, 
					max(backup_start_date) AS LastFullBackup    
				FROM 
					msdb.dbo.backupset bs INNER JOIN 
					master.sys.databases sd 
						ON bs.database_name = sd.name    
				WHERE 
					type IN ('D','I','L') AND 
					sd.state = 0 AND 
					sd.recovery_model_desc = 'FULL' AND 
					bs.backup_start_date > DATEADD(DD, -90,GETDATE())    
				GROUP BY sd.name, type   
				UNION  
				SELECT 
					sd.name, 
					type, 
					max(backup_start_date) AS LastFullBackup    
				FROM 
					msdb.dbo.backupset bs INNER JOIN 
					master.sys.databases sd 
						ON bs.database_name = sd.name    
				WHERE 
					type IN ('D','I') AND 
					sd.state = 0 AND 
					sd.recovery_model_desc = 'SIMPLE' AND 
					bs.backup_start_date > DATEADD(DD, -90,GETDATE())    
				GROUP BY sd.name, type   
	   )    
	   SELECT [Database], [Type], [Last Backup]     
	   FROM LastBackupDate    
	   WHERE [Last Backup] <= DATEADD(day, -7, GETDATE())    
	   ORDER BY [Database]
   END