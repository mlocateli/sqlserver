
--consulta
select top 1 *
from MDB.dbo.ADM_PAINEL_INCIDENTES_SOLUCIONADOS_MES_ATUAL
for xml auto, type, elements, root('rows')

--cmdshell ok
exec xp_cmdshell 'bcp "select top 10 * from MDB.dbo.ADM_PAINEL_INCIDENTES_SOLUCIONADOS_MES_ATUAL for xml auto, elements, root(''row'')" queryout c:\ferias.xml -S dbgerp27sqla\dbgerp27sqla -T -c'

