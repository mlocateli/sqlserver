USE [master]
GO

/****** Object:  StoredProcedure [dbo].[sp_checksize]    Script Date: 22/09/2015 10:41:43 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[sp_checksize]
(
       @database sysname = '%%',
       @filegroup sysname = '%%',
       @groupsize_mb decimal(16,2) = 0.00,
       @available_mb decimal(16,2) = 99999999.99,
       @available_perc decimal(16,2) = 99999999.99,
       @order_by varchar(100) = 'db_name'
)
AS
BEGIN

/*** Declara a variável para executar o comando, e cria a tabela temporária para armazenar os resultados ***/
DECLARE @sql varchar(max);
DECLARE @sql2 varchar(max);
CREATE TABLE #tempsize (db_name sysname, filegroup sysname, groupsize_mb decimal(16,2), available_mb decimal(16,2), available_perc decimal(16,2))

/*** Comando para verificar o espaço dos datafiles/logfiles em cada banco ***/
SELECT @sql = 'USE [?]; 

BEGIN TRY
	INSERT INTO #tempsize
	SELECT
		db_name() [Database]
		,ISNULL (g.groupname, ''LOG'') as [Filegroup]
		,CAST(
			SUM((size)/128.0) as decimal(16,2)
			)
		as [Group Size MB]
		,CAST(
			SUM(((size)/128.0) - CAST(FILEPROPERTY(name, ''SpaceUsed'') AS int)/128.0) as decimal(16,2)
			) 
		as [Available MB]
		,CAST(
			SUM((((size)/128.0) - CAST(FILEPROPERTY(name, ''SpaceUsed'') AS int)/128.0)) / sum(((size)/128.0)) * 100 as decimal(16,2)
			) 
		as [Available %]
	FROM sysfiles f left join sysfilegroups g
	ON f.groupid = g.groupid
	GROUP BY g.groupname;

END TRY
BEGIN CATCH
	SELECT 
        ERROR_NUMBER() AS ErrorNumber
        ,ERROR_MESSAGE() AS ErrorMessage;
END CATCH'

EXEC sp_msforeachdb @sql

SET @sql2 = '
SELECT 
	db_name [Database], filegroup [Filegroup], groupsize_mb [Group Size MB], 
	available_mb [Available MB], available_Perc [Available %] 
	FROM #tempsize
	WHERE db_name LIKE ''' + @database + ''' AND
	filegroup LIKE ''' + @filegroup + ''' AND
	groupsize_mb >= ''' + convert(nvarchar(max), @groupsize_mb) + ''' AND
	available_mb <= ''' + convert(nvarchar(max), @available_mb) + ''' AND 
	available_perc <= ''' + convert(nvarchar(max), @available_perc) + ''' 
	ORDER BY ' + @order_by;

EXEC (@sql2);

DROP TABLE #tempsize;

/*** Fim ***/
END

GO