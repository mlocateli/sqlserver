USE [master]
GO

/****** Object:  StoredProcedure [dbo].[sp_dbsizealert]    Script Date: 13/08/2015 15:30:58 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[sp_dbsizealert] (@FileType INT)
AS
BEGIN

CREATE TABLE  #Databases  (db_name sysname, used_space float )

DECLARE @CMD AS NVARCHAR(1000) 

SET @CMD = ' use ?; 
								insert into #Databases 
								select
										db_name(database_id) [database],
										avg(cast(cast(fileproperty(a.name, ''spaceused'') as float)/cast(size as float) * 100 as decimal(10,1))) [used %]
									from 
										sys.master_files a
									where 
										type = '+CAST(@FileType AS CHAR)+' and database_id = db_id()  /* 0 = Datafile / 1 = Logfile */
									group by 
										db_name(database_id)' 

		EXEC  sp_msforeachdb @CMD

		SELECT  *
		FROM  #Databases
		ORDER BY used_space DESC

		DROP TABLE #Databases

END
GO