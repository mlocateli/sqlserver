CREATE procedure [dbo].[sp_requests]    
(    
 @order_by varchar(200) = 'session_id',    
 @session_id varchar(200) = '%%',    
 @login_name varchar(200) = '%%',    
 @request_status varchar(200) = '%%',    
 @session_status varchar(200) = '%%',    
 @command varchar(200) = '%%',    
 @database varchar(200) = '%%',    
 @blocked_by varchar(200) = '%%',    
 @wait_time varchar(200) = '%%',    
 @wait_type varchar(200) = '%%',    
 @last_wait_type varchar(200) = '%%',    
 @wait_resource varchar(200) = '%%',    
 @last_request_start_time varchar(200) = '%%',    
 @last_request_end_time varchar(200) = '%%',    
 @cpu_time varchar(200) = '%%',     
 @session_cpu_time varchar(200) = '%%',    
 @logical_reads varchar(200) = '%%',    
 @reads varchar(200) = '%%',    
 @writes varchar(200) = '%%',    
 @host_name varchar(200) = '%%',    
 @client_net_address varchar(200) = '%%',    
 @program_name varchar(200) = '%%',    
 @host_process_id varchar(200) = '%%',    
 @memory_usage varchar(200) = '%%',    
 @open_tran_count varchar(200) = '%%',    
 @percent_complete varchar(200) = '%%',    
 @text varchar(200) = '%%'    
    
)    
as     
begin    
 declare @query nvarchar(max)    
 declare @query2 nvarchar(max)    
     
 set @query = 'select    
  c.session_id [session_id],    
  a.login_name [login_name],    
  c.status [request_status],    
  a.status [session_status],    
  c.command [command],    
  db_name(c.database_id) [database],    
  c.blocking_session_id [blocked_by],    
  c.wait_time [wait_time],    
  c.wait_type [wait_type],    
  c.last_wait_type [last_wait_type],    
  c.wait_resource [wait_resource],    
  a.last_request_start_time [last_request_start_time],    
  a.last_request_end_time [last_request_end_time],    
  c.cpu_time [cpu_time],    
  a.cpu_time [session_cpu_time],    
  c.logical_reads [logical_reads],    
  c.reads [reads],    
  c.writes [writes],    
  a.program_name [program_name],    
  a.host_name [host_name],    
  b.client_net_address [client_net_address],    
  a.host_process_id [host_process_id],    
  a.memory_usage [memory_usage],    
  c.open_transaction_count [open_tran_count],    
  c.percent_complete [percent_complete],    
  q.text [text]    
 from    
  sys.dm_exec_sessions a    
  inner join sys.dm_exec_connections b on a.session_id = b.session_id    
  inner join sys.dm_exec_requests c on a.session_id = c.session_id    
  cross apply sys.dm_exec_sql_text(c.sql_handle) AS q    
 where    
  a.is_user_process = 1 --user connection    
  and    
  a.session_id <> @@SPID    
  and    
  (c.session_id LIKE ''' + @session_id + ''' OR c.session_id IS NULL)    
  and    
  (a.login_name LIKE ''' + @login_name + ''' OR a.login_name IS NULL)    
  and    
  (c.status LIKE ''' + @request_status + ''' OR c.status IS NULL)    
  and    
  (c.command LIKE ''' + @command + ''' OR c.command IS NULL)    
  and    
  (db_name(c.database_id) LIKE ''' + @database + ''' OR c.database_id IS NULL)    
  and    
  (c.blocking_session_id LIKE ''' + @blocked_by + ''' OR c.blocking_session_id IS NULL)    
  and    
  (c.wait_time LIKE ''' + @wait_time + ''' OR c.wait_time IS NULL)    
  and    
  (c.wait_type LIKE ''' + @wait_type + ''' OR c.wait_type IS NULL)    
  and    
  (c.last_wait_type LIKE ''' + @last_wait_type + ''' OR c.last_wait_type IS NULL)    
  and    
  (c.wait_resource LIKE ''' + @wait_resource + ''' OR c.wait_resource IS NULL)    
  and    
  (c.open_transaction_count LIKE ''' + @open_tran_count + ''' OR c.open_transaction_count IS NULL)    
  and    
  (c.percent_complete LIKE ''' + @percent_complete + ''' OR c.percent_complete IS NULL)    
  and    
  (c.cpu_time LIKE ''' + @cpu_time + ''' OR c.cpu_time IS NULL)    
  and    
  (c.reads LIKE ''' + @reads + ''' OR c.reads IS NULL)    
  and    
  (c.writes LIKE ''' + @writes + ''' OR c.writes IS NULL)    
  and    
  (c.logical_reads LIKE ''' + @logical_reads + ''' OR c.logical_reads IS NULL)    
  and    
  (a.host_name LIKE ''' + @host_name + ''' OR a.host_name IS NULL)    
  and    
  (a.program_name LIKE ''' + @program_name + ''' OR a.program_name IS NULL)    
  and    
  (a.host_process_id LIKE ''' + @host_process_id + ''' OR a.host_process_id IS NULL)    
  and    
  (a.status LIKE ''' + @session_status + ''' OR a.status IS NULL)    
  and    
  (a.cpu_time LIKE ''' + @session_cpu_time + ''' OR a.cpu_time IS NULL)    
  and    
  (a.memory_usage LIKE ''' + @memory_usage + ''' OR a.memory_usage IS NULL)    
  and    
  (a.last_request_start_time LIKE ''' + @last_request_start_time + ''' OR a.last_request_start_time IS NULL)    
  and    
  (a.last_request_end_time LIKE ''' + @last_request_end_time + ''' OR a.last_request_end_time IS NULL)    
  and    
  (b.client_net_address LIKE ''' + @client_net_address + ''' OR b.client_net_address IS NULL)    
  and    
  (q.text LIKE ''' + @text + ''' OR q.text IS NULL)    
 order by ' + @order_by    
    
 set @query2 = 'select a.login_name, c.status, count(*) total    
 from    
  sys.dm_exec_sessions a    
  inner join sys.dm_exec_requests c on a.session_id = c.session_id    
 where    
  a.is_user_process = 1 --user connection    
  and    
  a.session_id <> @@SPID    
 group by a.login_name, c.status    
 order by a.login_name'    
    
 --print (@query)    
 exec (@query)    
 --exec (@query2)    
end    
    
    