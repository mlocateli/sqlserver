
-- remove datafile

https://www.mssqltips.com/sqlservertip/4349/how-to-remove-a-sql-server-data-file-for-a-multidata-file-database/

USE EvolutionHist;
go

DBCC showfilestats

DBCC SHRINKFILE ('EvolutionHIST_Data3', EMPTYFILE);

DBCC showfilestats

USE master;
GO
ALTER DATABASE EvolutionHist
REMOVE FILE EvolutionHIST_Data3;
GO
