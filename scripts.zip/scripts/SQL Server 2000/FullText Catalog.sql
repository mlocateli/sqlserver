
use [FAS] 

exec sp_fulltext_catalog N'FAS', N'start_incremental'

exec sp_fulltext_catalog N'FAS', N'rebuild'

exec sp_fulltext_catalog 'FAS', 'rebuild', 'D:\MSSQL$TEST\Data\FAS\FullTextCatalog'

SELECT FULLTEXTCATALOGPROPERTY('FAS', 'path')

EXEC sp_help_fulltext_catalogs 'FAS' 

SELECT name, ftcatid FROM sysobjects WHERE ftcatid > 0

EXEC sp_fulltext_table 'Failure_Analysis', 'drop'

DROP catalog 'FAS'

sp_fulltext_database 'disable' 

sp_fulltext_database 'enable'

select * from sysfulltextcatalogs

update sysfulltextcatalogs
set path = 'D:\MSSQL$TEST\FTDATA'
where name = 'FAS'


