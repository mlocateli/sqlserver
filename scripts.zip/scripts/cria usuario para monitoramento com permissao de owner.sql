/*
Script cria usuario para monitoramento com permissao de owner
*/

USE [master]
GO
EXEC master.dbo.sp_addlogin @loginame = 'IBMTMOQ', @passwd = 'monitora', @defdb = 'tempdb'

set nocount on

create table #bancos(
    Ordem int identity(1, 1) not null,
    Nome varchar(200) not null,
    Cmptlevel tinyint
)

insert #bancos (Nome, Cmptlevel) 
   select name, cmptlevel from master..sysdatabases 
   order by 1 

declare @ordem int, @total int, @existe_sp int, @Nome_banco varchar(200), @comando varchar(200), @Cmptlevel tinyint

select @ordem = 1, @total=count(*) from #bancos

while (@ordem <= @total)
   begin
      select @Nome_banco = Nome, @Cmptlevel = Cmptlevel from #bancos where Ordem = @ordem

            set @comando = 'osql -E -q "EXEC dbo.sp_grantdbaccess @loginame = ''IBMTMOQ'', @name_in_db = ''IBMTMOQ''" -d ' + @Nome_banco + ' -S ' + @@servername
			exec xp_cmdshell @comando

            set @comando = 'osql -E -q "EXEC sp_addrolemember ''db_owner'', ''IBMTMOQ''" -d ' + @Nome_banco + ' -S ' + @@servername
			exec xp_cmdshell @comando

      set @ordem = @ordem + 1
   end

drop table #bancos

set nocount off