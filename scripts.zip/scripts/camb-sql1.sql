/*
Cria��o de Indice
*/

USE [MSS]
GO

/****** Object:  Index [IDX_Prefix_BidNo]    Script Date: 02/25/2013 14:53:02 ******/
CREATE NONCLUSTERED INDEX [IDX_Prefix_BidNo] ON [dbo].[IMO_Bid_Number] 
(
	[prefix] ASC,
	[bid_no] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO