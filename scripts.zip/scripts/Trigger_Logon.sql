
/*

Limita o n�mero de conex�es por host de um mesmo login

*/

ALTER TRIGGER COMPE_connection_limit_trigger
ON ALL SERVER --WITH EXECUTE AS 'app_cambio'
FOR LOGON
AS
BEGIN
	DECLARE @hostname VARCHAR(50)
	SELECT @hostname = host_name FROM sys.dm_exec_sessions WHERE session_id = @@spid

	IF ORIGINAL_LOGIN() like 'app_cambio%'
	BEGIN
		IF ((SELECT COUNT(*) FROM sys.dm_exec_sessions WHERE is_user_process = 1 AND original_login_name like 'app_cambio%' AND host_name = @hostname) > 5)
		ROLLBACK;
	END;
END;

ENABLE TRIGGER [COMPE_connection_limit_trigger] ON ALL SERVER
GO

DISABLE TRIGGER [COMPE_connection_limit_trigger] ON ALL SERVER
GO

GRANT VIEW SERVER STATE TO app_cambio;
GO

