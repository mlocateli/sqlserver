    SET NOCOUNT ON 
    IF OBJECT_ID('tempdb..#SpaceUsed') IS NOT NULL DROP TABLE #SpaceUsed

    CREATE TABLE #SpaceUsed 
    (
    TableName sysname ,
    [Rows] int ,
    [Reserved] varchar(20),
    [Data] varchar(20),
    [Index_Size] varchar(20),
    [Unused] varchar(20),
    [Reserved_GB] bigint,
    [Data_GB] bigint,
    [Index_Size_GB] bigint,
    [Unused_MB] bigint
    )

    DECLARE @CMD NVARCHAR(MAX) =''
    SELECT @CMD +='EXEC sp_spaceused ' +  ''''+QUOTENAME(TABLE_SCHEMA)+'.'+ QUOTENAME(TABLE_NAME)+''''+';'+CHAR(10)
    FROM INFORMATION_SCHEMA.TABLES 
    --PRINT @CMD

     INSERT INTO #SpaceUsed (TableName ,[Rows] , [Reserved], [Data] , [Index_Size] , [Unused] )
     EXEC sp_executesql @CMD

	 -- select * from #SpaceUsed

     UPDATE #SpaceUsed 
     SET [Reserved_GB] = CONVERT(BIGINT,RTRIM(LTRIM(REPLACE([Reserved] , ' KB', '')))/1024/1024),
         [Data_GB] = CONVERT(BIGINT,RTRIM(LTRIM(REPLACE([Data] , ' KB', '')))/1024/1024),
         [Index_Size_GB]= CONVERT(BIGINT,RTRIM(LTRIM(REPLACE([Index_Size] , ' KB', '')))/1024/1024),
         [Unused_MB]= CONVERT(BIGINT,RTRIM(LTRIM(REPLACE([Unused] , ' KB', '')))/1024)


     SELECT TableName, Rows/1000/1000 [Rows_MM], [Reserved_GB], [Data_GB], [Index_Size_GB], [Unused_MB]
     FROM #SpaceUsed
     ORDER BY Data_GB DESC 

     --SELECT SUM(Reserved_KB) Reserved_KB , SUM(Data_KB) Data_KB, SUM(Index_Size_KB) Index_Size_KB , SUM(Unused_KB) Unused_KB ,SUM(Data_KB / 1024.0) Data_MB , SUM(Data_KB / 1024.0 / 1024.0) Data_GB
     --FROM #SpaceUsed

     DROP TABLE #SpaceUsed

