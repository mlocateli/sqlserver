/* For security reasons the login is created disabled and with a random password. */
/****** Object:  Login [sa_ibm]    Script Date: 11/09/2010 18:41:46 ******/

CREATE LOGIN [sa_ibm] WITH PASSWORD=N'?�?(Hl>�x?�?|$�{�G����M@3����7�', DEFAULT_DATABASE=[master], DEFAULT_LANGUAGE=[us_english], CHECK_EXPIRATION=OFF, CHECK_POLICY=OFF
GO

EXEC sys.sp_addsrvrolemember @loginame = N'sa_ibm', @rolename = N'sysadmin'
GO

ALTER LOGIN [sa_ibm] DISABLE
GO

