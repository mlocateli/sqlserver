
-- usando BCP para export de Dados/Arquivos

bcp "SELECT * FROM [Siscomp].[dbo].[DOC_SR_BKP]" queryout \\nas01\backup_mssql\RESTORE\ExcelTest.csv -t, -c -S . -d Siscomp -T
bcp "SELECT * FROM [Siscomp].[dbo].[CHQ_NR_BKP_1]" queryout \\nas01\backup_mssql\RESTORE\ExcelTestx.csv -t, -c -S . -d Siscomp -T

declare @sql varchar(8000) 
select @sql  = 'bcp ExcelAnalysis.dbo.vw_ClearDB out c:\csv\comm.txt -c -t, -T -S '+ @@servername 
exec master..xp_cmdshell @sql


-- BCP IN runing from command line 
bcp dba.dbo.TesteBulkImport in tableToImport.txt -c -t, -T -S db0npc1p
